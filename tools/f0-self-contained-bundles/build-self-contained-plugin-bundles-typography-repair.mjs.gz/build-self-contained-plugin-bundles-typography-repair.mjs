
import { execFileSync } from 'node:child_process';
import { mkdir, readFile, writeFile, rm, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { createHash } from 'node:crypto';

const REPO = process.env.GITHUB_REPOSITORY || 'onedayonemasterpiece/lovekgd-design-system';
const ISSUE = '57';
const STANDARD_GLOBAL = 'KenigEventsPenpotBundle';
const LEGACY_GLOBAL = 'KenigeventsF0DirectPluginBundle';
const HARNESS = {
  head: '9ab3696f1053ba41ecd4ac7bf1f52ef3427d145b',
  tree: 'f0603efe12801a9beb3a156eefd8bff12544246b',
  path: 'tests/asp-production-conveyor-v3/d0/d0_plugin_bundle_conformance_v1.mjs',
  blob: '9a555027104208723bc9d90e1f888c183461dce8',
};

const ALL_ITEMS = [
  {
    key: 'medallions',
    lane: 1,
    id: 'F-MEDALLIONS-INSTITUTIONS-A-R4-SELF-CONTAINED-BUNDLE',
    kind: 'medallions',
    sourceBranch: 'd0/f-medallions-institutions-a-r4-conformance-repair-v1-20260902',
    sourceHead: '14b9a100b4a588ce3de0734beeea2bafaf53ffa5',
    originalBranch: 'f0/f-medallions-institutions-a-r3-runtime-repair-20260902',
    originalHead: '416a20779905d9d57d0fe5e7d6447565b7094036',
    implementationBranch: 'd0/f-medallions-institutions-a-r2-native-staged-v1-20260902',
    implementationHead: 'f95ae5b9a3f898862b7d3c527cba88fb5641e15c',
    dir: 'executables/asp-production-conveyor-v3/f0/f-medallions-institutions-a-r4-self-contained-bundle',
    sourceTestDir: 'executables/asp-production-conveyor-v3/f0/f-medallions-institutions-a-r3-runtime',
    branch: 'f0/f-medallions-institutions-a-self-contained-plugin-bundle-v1-20260902',
  },
  {
    key: 'colors-status',
    lane: 2,
    id: 'F-FOUNDATIONS-REVIEW-COLORS-STATUS-R4-SELF-CONTAINED-BUNDLE',
    kind: 'foundation',
    sourceBranch: 'f0/f-foundations-review-colors-status-r5-d0-conformant-bundle-20260902',
    sourceHead: '5ec1068282b22565812b956438637f599f381bb9',
    originalBranch: 'f0/f-foundations-review-colors-status-r3-runtime-20260902',
    originalHead: '013ddc7199350d29704fe786aba00f7db54d992e',
    dir: 'executables/asp-production-conveyor-v3/f0/f-foundations-review-colors-status-r4-self-contained-bundle',
    sourceTestDir: 'executables/asp-production-conveyor-v3/f0/f-foundations-review-colors-status-r3-runtime',
    branch: 'f0/f-foundations-review-colors-status-self-contained-plugin-bundle-v1-20260902',
  },
  {
    key: 'spacing-sizing',
    lane: 2,
    id: 'F-FOUNDATIONS-REVIEW-SPACING-SIZING-R4-SELF-CONTAINED-BUNDLE',
    kind: 'foundation',
    sourceBranch: 'f0/f-foundations-review-spacing-sizing-r5-d0-conformant-bundle-20260902',
    sourceHead: '1e072614a3601d12dbb43b8c6c48a1c495073ed6',
    originalBranch: 'f0/f-foundations-review-spacing-sizing-r3-runtime-20260902',
    originalHead: '47890d81360b21f9de43b3c568aeba49c422878b',
    dir: 'executables/asp-production-conveyor-v3/f0/f-foundations-review-spacing-sizing-r4-self-contained-bundle',
    sourceTestDir: 'executables/asp-production-conveyor-v3/f0/f-foundations-review-spacing-sizing-r3-runtime',
    branch: 'f0/f-foundations-review-spacing-sizing-self-contained-plugin-bundle-v1-20260902',
  },
  {
    key: 'shape-elevation',
    lane: 2,
    id: 'F-FOUNDATIONS-REVIEW-SHAPE-ELEVATION-R4-SELF-CONTAINED-BUNDLE',
    kind: 'foundation',
    sourceBranch: 'f0/f-foundations-review-shape-elevation-r5-d0-conformant-bundle-20260902',
    sourceHead: 'abf6de3431ccdee05e494c84c039e684e7a8e567',
    originalBranch: 'f0/f-foundations-review-shape-elevation-r3-runtime-20260902',
    originalHead: 'e0efd184a5c9c858262ea5759f48661546bf0932',
    dir: 'executables/asp-production-conveyor-v3/f0/f-foundations-review-shape-elevation-r4-self-contained-bundle',
    sourceTestDir: 'executables/asp-production-conveyor-v3/f0/f-foundations-review-shape-elevation-r3-runtime',
    branch: 'f0/f-foundations-review-shape-elevation-self-contained-plugin-bundle-v1-20260902',
  },
  {
    key: 'motion-accessibility',
    lane: 2,
    id: 'F-FOUNDATIONS-REVIEW-MOTION-ACCESSIBILITY-R4-SELF-CONTAINED-BUNDLE',
    kind: 'foundation',
    sourceBranch: 'f0/f-foundations-review-motion-accessibility-r5-d0-conformant-bundle-20260902',
    sourceHead: '213e252ca43b15e66d587d8da628760e0e10f797',
    originalBranch: 'f0/f-foundations-review-motion-accessibility-r3-runtime-20260902',
    originalHead: '95a09ce213e99b5b1774e74cc808f216d113697d',
    dir: 'executables/asp-production-conveyor-v3/f0/f-foundations-review-motion-accessibility-r4-self-contained-bundle',
    sourceTestDir: 'executables/asp-production-conveyor-v3/f0/f-foundations-review-motion-accessibility-r3-runtime',
    branch: 'f0/f-foundations-review-motion-accessibility-self-contained-plugin-bundle-v1-20260902',
  },
  {
    key: 'type-scale',
    lane: 3,
    id: 'F-TYPOGRAPHY-TYPE-SCALE-R4-SELF-CONTAINED-BUNDLE',
    kind: 'typography',
    sourceBranch: 'f0/f-typography-type-scale-r5-d0-conformant-bundle-20260902',
    sourceHead: '975545d04626a0cb1e1a845fb684f6f2ec062531',
    originalBranch: 'f0/f-typography-type-scale-r3-runtime-20260902',
    originalHead: 'f78b66be7dea3f4eebd3ae1d65cc1a390c1d12c9',
    dir: 'executables/asp-production-conveyor-v3/f0/f-typography-type-scale-r4-self-contained-bundle',
    sourceTestDir: 'executables/asp-production-conveyor-v3/f0/f-typography-type-scale-r3-runtime',
    branch: 'f0/f-typography-type-scale-self-contained-plugin-bundle-v1-20260902',
  },
  {
    key: 'layout-rules',
    lane: 3,
    id: 'F-TYPOGRAPHY-LAYOUT-RULES-R4-SELF-CONTAINED-BUNDLE',
    kind: 'typography',
    sourceBranch: 'f0/f-typography-layout-rules-r5-d0-conformant-bundle-20260902',
    sourceHead: 'ce0475a49bd69a6195e4e47e29f2c066ffd5ff3c',
    originalBranch: 'f0/f-typography-layout-rules-r3-runtime-20260902',
    originalHead: 'eb35e5f2c0a4a1b7bb2313f41751401f3273c2b0',
    dir: 'executables/asp-production-conveyor-v3/f0/f-typography-layout-rules-r4-self-contained-bundle',
    sourceTestDir: 'executables/asp-production-conveyor-v3/f0/f-typography-layout-rules-r3-runtime',
    branch: 'f0/f-typography-layout-rules-self-contained-plugin-bundle-v1-20260902',
  },
];

const ITEMS = ALL_ITEMS.filter((item) => item.kind === 'typography');
const EXISTING_PRIMARY_RESULTS = Object.freeze([{"key":"medallions","lane":1,"id":"F-MEDALLIONS-INSTITUTIONS-A-R4-SELF-CONTAINED-BUNDLE","kind":"medallions","sourceHead":"14b9a100b4a588ce3de0734beeea2bafaf53ffa5","sourceTree":"52a61567046297b12ca515fd1a0bae14cbc00fff","branch":"f0/f-medallions-institutions-a-self-contained-plugin-bundle-v1-20260902","head":"0bf133f15867261fc92d13a12da7cc27842ee76a","tree":"c82a6beef0fc4fe256f0d2ce1e6a0e087fcb15be","bundle":{"path":"executables/asp-production-conveyor-v3/f0/f-medallions-institutions-a-r4-self-contained-bundle/dist/penpot-plugin.bundle.js","blob":"469df884b7a0338d1f6940c851f76bfa88b45c28","bytes":609683,"sha256":"4636b581427bf8b5a520ed71c5cce0797058697e2284b63f4d622154f2289583"},"comment":5514452740},{"key":"colors-status","lane":2,"id":"F-FOUNDATIONS-REVIEW-COLORS-STATUS-R4-SELF-CONTAINED-BUNDLE","kind":"foundation","sourceHead":"5ec1068282b22565812b956438637f599f381bb9","sourceTree":"1e094dd205343fb4681bcdf5e30157bd33bd5b34","branch":"f0/f-foundations-review-colors-status-self-contained-plugin-bundle-v1-20260902","head":"656dfbf6ba9a5ee885588cc649177c5aa749adf0","tree":"4d0b607a3596e48666ff4690f38d22ce8d577288","bundle":{"path":"executables/asp-production-conveyor-v3/f0/f-foundations-review-colors-status-r4-self-contained-bundle/dist/penpot-plugin.bundle.js","blob":"f0dedad81e905d49ffe3e9c75d9f68bc331d5eb4","bytes":41735,"sha256":"d668e72351e116712d79834c49c2634e99239c31dbdf46c972d1407f8257107b"},"comment":5514451325},{"key":"spacing-sizing","lane":2,"id":"F-FOUNDATIONS-REVIEW-SPACING-SIZING-R4-SELF-CONTAINED-BUNDLE","kind":"foundation","sourceHead":"1e072614a3601d12dbb43b8c6c48a1c495073ed6","sourceTree":"87aad70e57920b4e621e19e615d0bc4ae7316c6f","branch":"f0/f-foundations-review-spacing-sizing-self-contained-plugin-bundle-v1-20260902","head":"bd37aba016c2b2522aa6183b60f44c989d6faea0","tree":"e7b092121f049615ff933335a85a0b501c373ebc","bundle":{"path":"executables/asp-production-conveyor-v3/f0/f-foundations-review-spacing-sizing-r4-self-contained-bundle/dist/penpot-plugin.bundle.js","blob":"7010c73d7b17f45e02764c2c7cd63cb9449f3b49","bytes":37880,"sha256":"283a1673aee2ea5e51c26c380c1dd932a46dff01914fd6a8c8cca3064461d97b"},"comment":5514450784},{"key":"shape-elevation","lane":2,"id":"F-FOUNDATIONS-REVIEW-SHAPE-ELEVATION-R4-SELF-CONTAINED-BUNDLE","kind":"foundation","sourceHead":"abf6de3431ccdee05e494c84c039e684e7a8e567","sourceTree":"3f099ac99d663fe323716ad6557a6e07cd7e7ec4","branch":"f0/f-foundations-review-shape-elevation-self-contained-plugin-bundle-v1-20260902","head":"f8a7d004b719b072c20450ef6ea3309717946200","tree":"f55a686f185d4d2e1a185f4665b1eda0affb96cd","bundle":{"path":"executables/asp-production-conveyor-v3/f0/f-foundations-review-shape-elevation-r4-self-contained-bundle/dist/penpot-plugin.bundle.js","blob":"37f1e6a7e555e37904cb05e12f18b76681b0e6db","bytes":36505,"sha256":"5e4e566321c8ee02270b65233d5294720ae41d85c7f7f6050468a59b97898762"},"comment":5514450210},{"key":"motion-accessibility","lane":2,"id":"F-FOUNDATIONS-REVIEW-MOTION-ACCESSIBILITY-R4-SELF-CONTAINED-BUNDLE","kind":"foundation","sourceHead":"213e252ca43b15e66d587d8da628760e0e10f797","sourceTree":"27c0efd05eed6c6ea84cad0382e6e6843e8c12d3","branch":"f0/f-foundations-review-motion-accessibility-self-contained-plugin-bundle-v1-20260902","head":"3f12fcba87c3bd68376a706c24400ce54bf08a4c","tree":"a44b177cc9607e6b7bb731fa94aaff6cd84551c2","bundle":{"path":"executables/asp-production-conveyor-v3/f0/f-foundations-review-motion-accessibility-r4-self-contained-bundle/dist/penpot-plugin.bundle.js","blob":"bfc418059dd52aa3c9ef4d81e61e3b701f5207be","bytes":37846,"sha256":"0961a2213370f325370a0e9ca3ef6e1174057c193d0532d746662fe9f3f8d478"},"comment":5514451933}]);

const FONT_FILES = {
  regular: {
    path: '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    family: 'DejaVu Sans',
    weight: 400,
    bytes: 759720,
    sha256: 'ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280',
  },
  bold: {
    path: '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
    family: 'DejaVu Sans',
    weight: 700,
    bytes: 708920,
    sha256: '5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895',
  },
};

const sh = (args, options = {}) => execFileSync(args[0], args.slice(1), {
  cwd: options.cwd || process.cwd(),
  encoding: options.binary ? null : 'utf8',
  stdio: options.inherit ? 'inherit' : ['ignore', 'pipe', 'pipe'],
  env: process.env,
});
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');

async function exactFonts() {
  const result = {};
  for (const [key, record] of Object.entries(FONT_FILES)) {
    const bytes = await readFile(record.path);
    if (bytes.length !== record.bytes) throw new Error(`FONT_BYTES:${key}:${bytes.length}`);
    const digest = sha256(bytes);
    if (digest !== record.sha256) throw new Error(`FONT_SHA:${key}:${digest}`);
    result[key] = { ...record, base64: bytes.toString('base64') };
  }
  return result;
}

function portableShaSource() {
  return String.raw`
function f0u8(v){var o=[],s=String(v);for(var i=0;i<s.length;i+=1){var c=s.charCodeAt(i);if(c>=55296&&c<=56319&&i+1<s.length){var d=s.charCodeAt(i+1);if(d>=56320&&d<=57343){c=65536+((c-55296)<<10)+(d-56320);i+=1}}if(c<128)o.push(c);else if(c<2048)o.push(192|(c>>>6),128|(c&63));else if(c<65536)o.push(224|(c>>>12),128|((c>>>6)&63),128|(c&63));else o.push(240|(c>>>18),128|((c>>>12)&63),128|((c>>>6)&63),128|(c&63))}return new Uint8Array(o)}
function f0sha(v){var a=v instanceof Uint8Array?Array.from(v):Array.from(f0u8(v)),k=[1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298],z=[1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225],lo=(a.length*8)>>>0,hi=Math.floor(a.length/536870912)>>>0,r=function(x,n){return(x>>>n)|(x<<(32-n))};a.push(128);while(a.length%64!==56)a.push(0);for(var i=3;i>=0;i-=1)a.push((hi>>>(i*8))&255);for(i=3;i>=0;i-=1)a.push((lo>>>(i*8))&255);for(var q=0;q<a.length;q+=64){var w=new Array(64);for(i=0;i<16;i+=1)w[i]=((a[q+4*i]<<24)|(a[q+4*i+1]<<16)|(a[q+4*i+2]<<8)|a[q+4*i+3])>>>0;for(i=16;i<64;i+=1){var x=w[i-15],y=w[i-2];w[i]=(w[i-16]+(r(x,7)^r(x,18)^(x>>>3))+w[i-7]+(r(y,17)^r(y,19)^(y>>>10)))>>>0}var A=z[0],B=z[1],C=z[2],D=z[3],E=z[4],F=z[5],G=z[6],H=z[7];for(i=0;i<64;i+=1){var t=(H+(r(E,6)^r(E,11)^r(E,25))+((E&F)^((~E)&G))+k[i]+w[i])>>>0,u=((r(A,2)^r(A,13)^r(A,22))+((A&B)^(A&C)^(B&C)))>>>0;H=G;G=F;F=E;E=(D+t)>>>0;D=C;C=B;B=A;A=(t+u)>>>0}z[0]=(z[0]+A)>>>0;z[1]=(z[1]+B)>>>0;z[2]=(z[2]+C)>>>0;z[3]=(z[3]+D)>>>0;z[4]=(z[4]+E)>>>0;z[5]=(z[5]+F)>>>0;z[6]=(z[6]+G)>>>0;z[7]=(z[7]+H)>>>0}return z.map(function(n){return n.toString(16).padStart(8,'0')}).join('')}
function f0b64(s){var a='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',q=String(s).replace(/[^A-Za-z0-9+/=]/g,''),o=[],i=0;while(i<q.length){var c1=a.indexOf(q.charAt(i++)),c2=a.indexOf(q.charAt(i++)),x3=q.charAt(i++),x4=q.charAt(i++),c3=x3==='='?-1:a.indexOf(x3),c4=x4==='='?-1:a.indexOf(x4);if(c1<0||c2<0)break;o.push((c1<<2)|(c2>>>4));if(c3>=0){o.push(((c2&15)<<4)|(c3>>>2));if(c4>=0)o.push(((c3&3)<<6)|c4)}}return new Uint8Array(o)}
`;
}

function standardLayer(item, input, recordBytes, sourceTree, fonts) {
  const fontManifest = fonts ? Object.fromEntries(Object.entries(fonts).map(([key, value]) => [
    key,
    {
      family: value.family,
      weight: value.weight,
      bytes: value.bytes,
      sha256: value.sha256,
      embedded: true,
    },
  ])) : {};
  const fontPayload = fonts ? Object.fromEntries(Object.entries(fonts).map(([key, value]) => [
    key,
    {
      bytes: value.bytes,
      sha256: value.sha256,
      base64: value.base64,
    },
  ])) : null;
  const manifest = {
    schema_version: 'kenigevents.self-contained-penpot-plugin-bundle.v1',
    package_id: item.id,
    state: 'DIRECT_PLUGIN_BUNDLE_READY_D0_QA_INTEGRATE',
    global_name: STANDARD_GLOBAL,
    entrypoints: {
      project: 'project',
      execute_phase: 'executePhase',
      settle: 'settle',
    },
    source_input: {
      branch: item.originalBranch,
      head: item.originalHead,
    },
    implementation_parent: {
      branch: item.sourceBranch,
      head: item.sourceHead,
      tree: sourceTree,
    },
    implementation_capital: item.implementationHead ? {
      branch: item.implementationBranch,
      head: item.implementationHead,
    } : null,
    package_record: input,
    package_record_bytes: recordBytes.length,
    package_record_sha256: sha256(recordBytes),
    exact_assets_embedded: item.kind === 'medallions' ? Number(input.spec?.assets?.length || 0) : 0,
    embedded_fonts: {
      count: Object.keys(fontManifest).length,
      records: fontManifest,
      semantic_contract: item.kind === 'typography' ? 'Inter-first' : null,
      frozen_evidence_family: item.kind === 'typography' ? 'DejaVu Sans' : null,
    },
    product_contract: {
      kind: item.kind,
      current_page_activation: true,
      maximum_creates_per_phase: 3,
      replay_created: 0,
      revision_bound_protected_projection: true,
      linked_atlas_header: 'ATLAS_PAGE_HEADER_V2',
      does_not_repair_eventcard_text: item.kind === 'typography',
    },
    artifact_contract: {
      one_classic_script: true,
      external_loaders: 0,
      server_globals: 0,
      file_api: 0,
      node_hash_api: 0,
      publisher_repack: false,
      publisher_source_copy: false,
      portable_sha256: true,
    },
  };
  const manifestJson = JSON.stringify(manifest);
  const fontJson = JSON.stringify(fontPayload);
  return `
(function(g){'use strict';
var core=g.${LEGACY_GLOBAL};if(!core)throw Error('LEGACY_CORE_MISSING');
var manifest=${manifestJson};
var fontSource=${fontJson};
${portableShaSource()}
function freeze(v){if(!v||typeof v!=='object'||Object.isFrozen(v))return v;Object.freeze(v);for(var k of Object.keys(v))freeze(v[k]);return v}
var fontCache=null;
function embeddedFonts(){if(!fontSource)return null;if(fontCache)return fontCache;var o={};for(var k of Object.keys(fontSource)){var r=fontSource[k],b=f0b64(r.base64);if(b.length!==r.bytes||f0sha(b)!==r.sha256)throw Error('EMBEDDED_FONT_IDENTITY:'+k);o[k]=b}fontCache=o;return o}
function host(v){if(!v||typeof v!=='object')throw Error('HOST_REQUIRED');var h=Object.create(v);var f=embeddedFonts();if(f)h.fontBytes=f;return h}
var p=typeof core.project==='function'?core.project:core.projection;
var e=typeof core.executePhase==='function'?core.executePhase:core.execution;
var s=typeof core.settle==='function'?core.settle:core.settlement;
if(typeof p!=='function'||typeof e!=='function'||typeof s!=='function')throw Error('CORE_ENTRYPOINT_MISSING');
function project(v){return p.call(core,host(v))}
function executePhase(v){return e.call(core,host(v))}
function settle(v){return s.call(core,host(v))}
var api={manifest:freeze(manifest),project:project,executePhase:executePhase,settle:settle};
var metadata=Object.freeze({schema:'D0_PLUGIN_BUNDLE_V1',package_id:${JSON.stringify(item.id)},bundle_sha256_binding:'EXTERNAL_AUTHORIZATION_TUPLE',global_name:${JSON.stringify(STANDARD_GLOBAL)},entrypoints:Object.freeze({projection:'projection',execution:'execution',settlement:'settlement'}),current_page_activation:true,max_creates_per_phase:3,replay_created:0});
Object.defineProperties(api,{metadata:{value:metadata},conformance:{value:core.conformance},projection:{value:project},execution:{value:executePhase},settlement:{value:settle},core:{value:core}});
Object.freeze(api);
Object.defineProperty(g,${JSON.stringify(STANDARD_GLOBAL)},{value:api,enumerable:true,configurable:false,writable:false});
})(globalThis);
`;
}

function buildScript() {
  return `import{readFile,writeFile}from'node:fs/promises';import{createHash}from'node:crypto';import{dirname,join}from'node:path';import{fileURLToPath}from'node:url';const d=dirname(fileURLToPath(import.meta.url)),a=await readFile(join(d,'src','base.bundle.plugin-v1.js'),'utf8'),b=await readFile(join(d,'src','kenig-events-standard-api.v1.js'),'utf8'),o=a.replace(/\\s*$/u,'')+'\\n'+b.replace(/^\\s*/u,''),p=join(d,'dist','penpot-plugin.bundle.js');if(process.argv.includes('--check')){if(await readFile(p,'utf8')!==o)throw Error('DETERMINISTIC_REGENERATION_MISMATCH')}else await writeFile(p,o,'utf8');console.log(JSON.stringify({bytes:Buffer.byteLength(o),sha256:createHash('sha256').update(o).digest('hex')}));`;
}

function transformSandbox(source, item) {
  let out = source
    .replaceAll(LEGACY_GLOBAL, STANDARD_GLOBAL)
    .replaceAll('.projection(', '.project(')
    .replaceAll('.settlement(', '.settle(')
    .replaceAll('c.fontBytes=await fonts();', '');
  out += `\ntest('canonical KenigEventsPenpotBundle contract and no caller byte injection',async()=>{const a=box();assert.equal(Object.keys(a).sort().join(','),'executePhase,manifest,project,settle');assert.equal(a.manifest.package_id,input.spec.package_id);assert.equal(a.manifest.global_name,'KenigEventsPenpotBundle');const c=ctx();assert.equal(Object.prototype.hasOwnProperty.call(c,'fontBytes'),false);const r=await a.project(c);assert.equal(r.package_id,input.spec.package_id);assert.equal(a.manifest.embedded_fonts.count,${item.kind === 'typography' ? 2 : 0})});\n`;
  return out;
}

async function prepareWorktree(item) {
  const wt = `/tmp/f0-standard-${item.key}`;
  await rm(wt, { recursive: true, force: true });
  sh(['git', 'worktree', 'add', '--detach', wt, item.sourceHead], { inherit: true });
  return { item, wt };
}

async function runOne(prepared, fonts) {
  const { item, wt } = prepared;
  const dir = join(wt, item.dir);
  try {
    const currentBundlePath = join(dir, 'dist', 'penpot-plugin.bundle.js');
    const currentBundle = await readFile(currentBundlePath, 'utf8');
    const inputPath = join(dir, 'bundle-input.v1.json');
    const recordBytes = await readFile(inputPath);
    const input = JSON.parse(recordBytes.toString('utf8'));
    if (input.spec?.package_id !== item.id) throw new Error(`PACKAGE_ID:${item.key}`);
    const sourceTree = sh(['git', 'rev-parse', 'HEAD^{tree}'], { cwd: wt }).trim();

    sh(['node', 'build-bundle.mjs', '--check'], { cwd: dir, inherit: true });
    sh(['node', '--test', 'penpot-plugin.bundle.sandbox.test.mjs'], { cwd: dir, inherit: true });

    const layer = standardLayer(item, input, recordBytes, sourceTree, item.kind === 'typography' ? fonts : null);
    const output = currentBundle.replace(/\s*$/u, '') + '\n' + layer.replace(/^\s*/u, '');
    const sandboxSource = await readFile(join(dir, 'penpot-plugin.bundle.sandbox.test.mjs'), 'utf8');
    const transformedSandbox = transformSandbox(sandboxSource, item);

    await mkdir(join(dir, 'src'), { recursive: true });
    await mkdir(join(dir, 'tests'), { recursive: true });
    await writeFile(join(dir, 'src', 'base.bundle.plugin-v1.js'), currentBundle);
    await writeFile(join(dir, 'src', 'kenig-events-standard-api.v1.js'), layer);
    await writeFile(currentBundlePath, output);
    await writeFile(join(dir, 'build-bundle.mjs'), buildScript());
    await writeFile(join(dir, 'penpot-plugin.bundle.sandbox.test.mjs'), transformedSandbox);
    await writeFile(join(dir, 'tests', 'd0_plugin_bundle_conformance_v1.mjs'), sh(['git', 'show', `${HARNESS.head}:${HARNESS.path}`]));

    await writeFile(join(dir, 'standard-bundle-authority.v1.json'), JSON.stringify({
      schema_version: 'kenigevents.self-contained-plugin-bundle-authority.v1',
      package_id: item.id,
      global_name: STANDARD_GLOBAL,
      source_input: { branch: item.originalBranch, head: item.originalHead },
      implementation_parent: { branch: item.sourceBranch, head: item.sourceHead, tree: sourceTree },
      d0_harness: HARNESS,
      penpot_reads: 0,
      penpot_mutations: 0,
      atlas_mutations: 0,
    }, null, 2) + '\n');

    sh(['node', 'build-bundle.mjs', '--check'], { cwd: dir, inherit: true });
    sh(['node', '--test', 'penpot-plugin.bundle.sandbox.test.mjs'], { cwd: dir, inherit: true });
    const sourceTest = join(wt, item.sourceTestDir, 'executor.v3.test.mjs');
    try {
      await stat(sourceTest);
      sh(['node', '--test', 'executor.v3.test.mjs'], { cwd: join(wt, item.sourceTestDir), inherit: true });
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
    }

    const bytes = await readFile(currentBundlePath);
    const digest = sha256(bytes);
    sh([
      'node',
      'tests/d0_plugin_bundle_conformance_v1.mjs',
      '--bundle',
      'dist/penpot-plugin.bundle.js',
      '--sha256',
      digest,
      '--global',
      STANDARD_GLOBAL,
    ], { cwd: dir, inherit: true });

    sh(['git', 'add', item.dir], { cwd: wt });
    sh([
      'git',
      '-c', 'user.name=F0 Plugin Bundle Builder',
      '-c', 'user.email=f0-plugin-bundle-builder@users.noreply.github.com',
      'commit',
      '-m', `fix(f0): standardize ${item.id} plugin bundle`,
    ], { cwd: wt, inherit: true });

    const head = sh(['git', 'rev-parse', 'HEAD'], { cwd: wt }).trim();
    const tree = sh(['git', 'rev-parse', 'HEAD^{tree}'], { cwd: wt }).trim();
    const bundlePath = `${item.dir}/dist/penpot-plugin.bundle.js`;
    const blob = sh(['git', 'rev-parse', `HEAD:${bundlePath}`], { cwd: wt }).trim();
    const buildBlob = sh(['git', 'rev-parse', `HEAD:${item.dir}/build-bundle.mjs`], { cwd: wt }).trim();
    const sandboxBlob = sh(['git', 'rev-parse', `HEAD:${item.dir}/penpot-plugin.bundle.sandbox.test.mjs`], { cwd: wt }).trim();
    const authorityBlob = sh(['git', 'rev-parse', `HEAD:${item.dir}/standard-bundle-authority.v1.json`], { cwd: wt }).trim();

    const existing = sh(['git', 'ls-remote', 'origin', `refs/heads/${item.branch}`]).trim();
    if (existing) throw new Error(`OUTPUT_BRANCH_EXISTS:${item.branch}:${existing}`);
    sh(['git', 'push', 'origin', `HEAD:refs/heads/${item.branch}`], { cwd: wt, inherit: true });
    const remote = sh(['git', 'ls-remote', 'origin', `refs/heads/${item.branch}`]).trim().split(/\s+/)[0];
    if (remote !== head) throw new Error(`PROVIDER_HEAD_MISMATCH:${item.key}`);

    const body = `<!-- ASP_BUILD_REQUEST_V2 -->
## ASP_BUILD_REQUEST_V2 — ${item.id} · canonical self-contained Penpot plugin bundle

\`\`\`yaml
state: DIRECT_PLUGIN_BUNDLE_READY_D0_QA_INTEGRATE
owner: F0
next_owner: D0_CONTINUOUS_INTAKE
lane: ${item.lane}
package_id: ${item.id}
source_input: {branch: ${item.originalBranch}, head: ${item.originalHead}}
implementation_parent: {branch: ${item.sourceBranch}, head: ${item.sourceHead}, tree: ${sourceTree}}
branch: ${item.branch}
head: ${head}
tree: ${tree}
force: false
bundle: {path: ${bundlePath}, git_blob_sha1: ${blob}, bytes: ${bytes.length}, sha256: ${digest}}
global_object: globalThis.${STANDARD_GLOBAL}
enumerable_api: [manifest, project, executePhase, settle]
self_contained: true
exact_package_record_embedded: true
exact_asset_or_font_bytes_embedded: ${item.kind === 'medallions' ? '8_assets' : item.kind === 'typography' ? '2_fonts' : 'package_local_records'}
runtime_external_loaders: 0
runtime_server_globals: 0
runtime_file_api: 0
runtime_node_hash_api: 0
publisher_rebundle_required: false
publisher_source_copy_required: false
deterministic_generation: PASS
browser_plugin_sandbox: PASS
production_projection: PASS
production_execution_phases: PASS
production_settlement: PASS
package_tests: PASS
D0_PLUGIN_BUNDLE_CONFORMANCE_V1: PASS
conformance_authority: {head: ${HARNESS.head}, tree: ${HARNESS.tree}, blob: ${HARNESS.blob}}
current_page_activation: PASS
max_native_creates_per_invocation: 3
replay_created: 0
build_blob: ${buildBlob}
sandbox_blob: ${sandboxBlob}
authority_blob: ${authorityBlob}
penpot_reads: 0
penpot_mutations: 0
atlas_mutations: 0
qa_pass_claimed: false
integrate_pass_claimed: false
\`\`\``;
    const comment = JSON.parse(sh(['gh', 'api', `repos/${REPO}/issues/${ISSUE}/comments`, '-f', `body=${body}`]));
    return {
      key: item.key,
      lane: item.lane,
      id: item.id,
      kind: item.kind,
      sourceHead: item.sourceHead,
      sourceTree,
      branch: item.branch,
      head,
      tree,
      bundle: {
        path: bundlePath,
        blob,
        bytes: bytes.length,
        sha256: digest,
      },
      buildBlob,
      sandboxBlob,
      authorityBlob,
      comment: comment.id,
    };
  } catch (error) {
    const body = `<!-- ASP_CONVEYOR_INCIDENT_V3 -->
## F0 self-contained plugin bundle conversion incident — ${item.id}

\`\`\`yaml
state: REPAIR
owner: F0
lane: ${item.lane}
package_id: ${item.id}
source_branch: ${item.sourceBranch}
source_head: ${item.sourceHead}
output_branch: ${item.branch}
error: ${JSON.stringify(String(error?.message || error))}
penpot_reads: 0
penpot_mutations: 0
atlas_mutations: 0
\`\`\``;
    try {
      sh(['gh', 'api', `repos/${REPO}/issues/${ISSUE}/comments`, '-f', `body=${body}`]);
    } catch {}
    throw error;
  }
}

async function main() {
  sh(['git', 'fetch', 'origin', '--prune'], { inherit: true });
  for (const ref of new Set([...ITEMS.map((item) => item.sourceHead), HARNESS.head])) {
    sh(['git', 'fetch', 'origin', ref], { inherit: true });
  }
  const fonts = await exactFonts();
  const prepared = [];
  for (const item of ITEMS) prepared.push(await prepareWorktree(item));

  let settled;
  try {
    settled = await Promise.allSettled(prepared.map((entry) => runOne(entry, fonts)));
  } finally {
    for (const entry of prepared) {
      try {
        sh(['git', 'worktree', 'remove', '--force', entry.wt], { inherit: true });
      } catch {}
    }
  }

  const failures = settled
    .map((result, index) => ({ result, item: ITEMS[index] }))
    .filter(({ result }) => result.status === 'rejected')
    .map(({ result, item }) => ({ id: item.id, error: String(result.reason?.stack || result.reason) }));
  const results = settled
    .filter((result) => result.status === 'fulfilled')
    .map((result) => result.value)
    .sort((a, b) => ITEMS.findIndex((item) => item.key === a.key) - ITEMS.findIndex((item) => item.key === b.key));

  const ready = failures.length === 0 && results.length === 2;
  const allResults = [...EXISTING_PRIMARY_RESULTS, ...results];
  const terminalState = ready ? 'F0_SELF_CONTAINED_BUNDLE_WAVE_READY' : 'F0_SELF_CONTAINED_BUNDLE_WAVE_REPAIR';
  const body = `<!-- ASP_CONVEYOR_CHECKPOINT_V3 -->
<!-- ${terminalState} -->
## ASP_CONVEYOR_CHECKPOINT_V3 — F0 canonical self-contained plugin bundle wave · typography repair

Supersedes partial checkpoint \`5514454065\`.

\`\`\`yaml
state: ${terminalState}
primary_packages: 7
bundles_ready:
${allResults.map((result) => `  - {id: ${result.id}, branch: ${result.branch}, head: ${result.head}, tree: ${result.tree}, bundle_blob: ${result.bundle.blob}, bundle_bytes: ${result.bundle.bytes}, bundle_sha256: ${result.bundle.sha256}, build_request: ${result.comment}}`).join('\n')}
exact_blockers:
${failures.length ? failures.map((failure) => `  - {id: ${failure.id}, error: ${JSON.stringify(failure.error)}}`).join('\n') : '  []'}
secondary_packages:
  brandbook: ${ready ? 'WORK_STEAL_ELIGIBLE' : 'NOT_STARTED_PRIMARY_NONTERMINAL'}
  copy_check: ${ready ? 'WORK_STEAL_ELIGIBLE' : 'NOT_STARTED_PRIMARY_NONTERMINAL'}
  extended_iconography: ${ready ? 'WORK_STEAL_ELIGIBLE' : 'NOT_STARTED_PRIMARY_NONTERMINAL'}
shared_foundation_bindings: NOT_EMITTED_PENDING_INDEPENDENT_D0_PASS
verification:
  canonical_global: ${allResults.length}/7
  deterministic_generation: ${allResults.length}/7
  browser_plugin_sandbox: ${allResults.length}/7
  package_tests: ${allResults.length}/7
  D0_PLUGIN_BUNDLE_CONFORMANCE_V1: ${allResults.length}/7
  provider_readback: ${allResults.length}/7
penpot_reads: 0
penpot_mutations: 0
atlas_mutations: 0
kaggle_used: false
new_foundation_families: 0
broad_package_wave_created: false
next_owner: D0_CONTINUOUS_INTAKE
\`\`\``;
  const terminalComment = JSON.parse(sh(['gh', 'api', `repos/${REPO}/issues/${ISSUE}/comments`, '-f', `body=${body}`]));
  await mkdir('artifacts', { recursive: true });
  await writeFile('artifacts/f0-self-contained-plugin-bundle-results.json', JSON.stringify({
    state: terminalState,
    ready,
    results: allResults,
    failures,
    terminalComment: terminalComment.id,
  }, null, 2) + '\n');
  console.log(JSON.stringify({ state: terminalState, terminalComment: terminalComment.id, results: allResults, failures }, null, 2));
  if (!ready) process.exit(1);
}

main().catch((error) => {
  console.error(error.stack || error);
  process.exit(1);
});
