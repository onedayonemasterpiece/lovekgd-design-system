#!/usr/bin/env python3
from __future__ import annotations

import copy
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "catalog/asp-production-conveyor-v3/a0"
TESTS = ROOT / "tests"
PR50_COMMIT = "9b8043f3bdb86fab4eee00bf94b0f10d4f029c50"
PR52_COMMIT = "b86bab3e91511b3d4bd7d953b22bceb847f02a51"
BASE_HEAD = "e5f00941c6c5ab14cdd2caa9c68a68edd3a1ce2c"
V6_COMMENT = 5481580183
PREVIOUS_CHECKPOINT = 5481262580
ROUTE_REGISTRY_SHA = "fb6f8252aba36eca906b6c1516ef19ef83532dda45c87ca0aa41c116773aae0d"
CASE_STRUCTURE_SHA = "7657be169a68f6df185bab7500511e725de05f7945ba76125fab4325d578c285"
CANONICAL_CORPUS_SHA = "b1746f0cd68be6dd6060858fb765c6863535aefbcf4844b9b50c279d69e9306a"
A0_CORRECTION_SHA = "d85b38c7883d53f43b628d885513c5851c164b25"

CONTRACT_FILES = [
    "search.semantic-contract.v1.json",
    "favorites.semantic-contract.v1.json",
    "personal-feed.semantic-contract.v1.json",
    "festivals.semantic-contract.v1.json",
    "interest-clubs.semantic-contract.v1.json",
    "artifacts.semantic-contract.v1.json",
    "event-detail.semantic-contract.v1.json",
    "focus-group.semantic-contract.v1.json",
    "information-pages.semantic-contract.v1.json",
    "special-state.semantic-contract.v1.json",
]
CONTRACT_BLOBS = {
    "archetype.search": "8ce71b4def54894be37c303125703f823b8eb9ca",
    "archetype.favorites": "459656f10abdb375b8e85788bce454a7ad7d69c4",
    "archetype.personal-feed": "a68a6f2ef96ba4dfa12b94a7e8502d7c8def0616",
    "archetype.festivals": "c9a5ceae36204eff6f52c766affd373d41003252",
    "archetype.interest-clubs": "fdf480026bb9fe9d83ffbb95440ce26f062c7c01",
    "archetype.artifacts": "eb030343b898794ed110000388b35daa22e8a9f4",
    "archetype.event-detail": "2fd2180a3f7ca11b5c12184ce6782d785394fbda",
    "archetype.focus-group": "798538de7bc3b6deff41dded3406195bb5803827",
    "archetype.information-pages": "aadec25c3dc7004e625694a38e99a21b98184d6d",
    "archetype.special-state": "22c2c8fa5dfc339fca870110ed9e3326de4444a6",
}
ACTIVE_STATES = {
    "archetype.search": "results",
    "archetype.favorites": "populated",
    "archetype.personal-feed": "profile-ready",
    "archetype.festivals": "ready",
    "archetype.interest-clubs": "catalog",
    "archetype.artifacts": "partial",
    "archetype.event-detail": "wide-image",
    "archetype.focus-group": "program",
    "archetype.information-pages": "partners-index",
    "archetype.special-state": "locked",
}
EXCLUDED_STATES = {
    "archetype.information-pages": ["legal-document"],
    "archetype.special-state": ["prelaunch-env", "unavailable"],
}
STEP_GAPS = {
    "archetype.interest-clubs": [
        "detail generated-route evidence remains unresolved; materialize candidate and require V0 current re-observation"
    ],
    "archetype.event-detail": [
        "PR50 contract also declares a tablet responsive branch; Wave 2 intentionally remains the exact twenty desktop/mobile cases"
    ],
    "archetype.information-pages": [
        "/legal/:slug/ is excluded because no current production source page is present in the repaired Wave 2 packet"
    ],
    "archetype.special-state": [
        "/:home-prelaunch-env/ is runtime-only and /:unavailable/ has no accepted dedicated route contract"
    ],
}


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_git_json(commit: str, path: str) -> Any:
    raw = subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=ROOT)
    return json.loads(raw.decode("utf-8"))


def git_blob(commit: str, path: str) -> str:
    return subprocess.check_output(["git", "rev-parse", f"{commit}:{path}"], cwd=ROOT, text=True).strip()


def canon(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def record_sha(obj: dict[str, Any], field: str) -> str:
    return hashlib.sha256(canon({k: v for k, v in obj.items() if k != field})).hexdigest()


def file_sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, obj: Any, *, pretty: bool = True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(obj, ensure_ascii=False, indent=2) + "\n" if pretty else json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    path.write_text(text, encoding="utf-8")


def contract_parts(contract: dict[str, Any]) -> tuple[list[str], list[str], list[str]]:
    regions = [x["region_id"] for x in sorted(contract["regions"], key=lambda x: x["order"])]
    components = [
        x["component_id"]
        for x in contract["component_dependencies"]
        if x.get("required") is True and x.get("dependency_type") != "unresolved_contract"
    ]
    states = [x["state_id"] for x in contract["states"] if x.get("required") is True]
    return regions, components, states


def run_json(command: list[str]) -> dict[str, Any]:
    result = subprocess.run(command, cwd=ROOT, check=True, text=True, capture_output=True)
    line = next((x for x in reversed(result.stdout.splitlines()) if x.strip().startswith("{")), None)
    if line is None:
        raise RuntimeError(f"No JSON result from {' '.join(command)}: {result.stdout}")
    return json.loads(line)


def build_wave2_source(contracts: dict[str, dict[str, Any]]) -> dict[str, Any]:
    old = load(BASE / "archetype-wave-2.v1.json")
    new = copy.deepcopy(old)
    focus = next(x for x in new["archetypes"] if x["archetype_id"] == "archetype.focus-group")
    focus_contract = contracts["archetype.focus-group"]
    focus["route_patterns"] = focus_contract["route_contract"]["route_patterns"]
    focus["source_pages"] = focus_contract["route_contract"]["source_pages"]
    new["source_version"] = 2
    new["supersedes"] = {
        "path": "catalog/asp-production-conveyor-v3/a0/archetype-wave-2.v1.json",
        "record_sha256": old["record_sha256"],
        "reason": "A0-WAVE2-FOCUS-ROUTE-FIDELITY-001",
    }
    new["repair_lineage"] = {
        "policy": "ASP_NONBLOCKING_WORK_STEALING_V6",
        "policy_comment": V6_COMMENT,
        "previous_checkpoint": PREVIOUS_CHECKPOINT,
        "defect_id": "A0-WAVE2-FOCUS-ROUTE-FIDELITY-001",
        "lowest_owner": "A0",
        "donor_contract": {
            "path": "catalog/global-archetype-sot-v1/archetype-contracts/focus-group.semantic-contract.v1.json",
            "commit": PR50_COMMIT,
            "git_blob_sha1": CONTRACT_BLOBS["archetype.focus-group"],
        },
        "restored_route_patterns": ["/fokus-gruppa/priglashenie/", "/fokus-gruppa/zavershenie/"],
        "restored_source_pages": [
            "site/src/pages/fokus-gruppa/priglashenie/index.astro",
            "site/src/pages/fokus-gruppa/zavershenie/index.astro",
        ],
        "scope": "SOURCE_FIDELITY_ONLY_NO_ROUTE_REDISTRIBUTION_NO_PENPOT",
    }
    new.pop("record_sha256", None)
    new["record_sha256"] = record_sha(new, "record_sha256")
    return new


def build_wave2_adapter(wave2: dict[str, Any], owner_index: dict[str, Any], contracts: dict[str, dict[str, Any]]) -> dict[str, Any]:
    source_by_id = {x["archetype_id"]: x for x in wave2["archetypes"]}
    steps: list[dict[str, Any]] = []
    contract_receipts: list[dict[str, Any]] = []
    expected_components: set[str] = set()
    evidence_keys: list[str] = []
    root_order: list[str] = []

    for index, filename in enumerate(CONTRACT_FILES):
        contract_path = f"catalog/global-archetype-sot-v1/archetype-contracts/{filename}"
        contract = load_git_json(PR50_COMMIT, contract_path)
        archetype_id = contract["archetype_id"]
        source = source_by_id[archetype_id]
        regions, components, all_states = contract_parts(contract)
        excluded = EXCLUDED_STATES.get(archetype_id, [])
        supported = [x for x in all_states if x not in excluded]
        active = ACTIVE_STATES[archetype_id]
        if active not in supported:
            raise AssertionError(f"active state {active} not supported for {archetype_id}")
        expected_components.update(components)
        contract_receipts.append({
            "archetype_id": archetype_id,
            "path": contract_path,
            "git_commit": PR50_COMMIT,
            "git_blob_sha1": CONTRACT_BLOBS[archetype_id],
            "route_patterns": source["route_patterns"],
            "source_pages": source["source_pages"],
            "contract_states": all_states,
            "materialization_states": supported,
            "excluded_unmaterialized_states": excluded,
        })
        slug = archetype_id.removeprefix("archetype.")
        for viewport in ("desktop", "mobile"):
            root = f"a0.candidate.root.archetype.{slug}.{viewport}.v1"
            scenario = f"a0.review.archetype.{slug}.{viewport}.v1"
            evidence = f"v0.{scenario}"
            step: dict[str, Any] = {
                "order": len(steps) + 1,
                "semantic_root_key": root,
                "scenario_id": scenario,
                "evidence_key": evidence,
                "archetype_id": archetype_id,
                "route_patterns": source["route_patterns"],
                "source_pages": source["source_pages"],
                "viewport": {
                    "id": viewport,
                    "width": 1280 if viewport == "desktop" else 390,
                    "height": 800 if viewport == "desktop" else 844,
                },
                "projection_ref": f"catalog/asp-production-conveyor-v3/a0/archetype-wave-2.v2.json#archetypes/{index}",
                "projection_sha256": wave2["record_sha256"],
                "fixture_ids": source["specimen_fixture_ids"],
                "fixture_semantics": source["fixture_semantics"],
                "contract_states": all_states,
                "required_states": supported,
                "excluded_unmaterialized_states": excluded,
                "active_candidate_state": active,
                "shell_ref": f"pr50.contract.{archetype_id}",
                "shell_semantic_slots": regions,
                "component_semantic_refs": components,
                "archetype_contract_ref": {
                    "path": contract_path,
                    "git_commit": PR50_COMMIT,
                    "git_blob_sha1": CONTRACT_BLOBS[archetype_id],
                },
                "expected_instances": {
                    "semantic_roots": 1,
                    "semantic_region_slots": len(regions),
                    "specimen_record_bindings": len(source["specimen_fixture_ids"]),
                    "required_component_bindings": len(components),
                    "required_state_bindings": len(supported),
                    "excluded_state_receipts": len(excluded),
                },
                "geometry_authority": "VIEWPORT_FROM_PR50_ROUTE_REGISTRY; U0/F0 OWN_COMPONENT_AND_ACCEPTANCE_GEOMETRY",
            }
            if archetype_id in STEP_GAPS:
                step["explicit_gaps"] = STEP_GAPS[archetype_id]
            steps.append(step)
            root_order.append(root)
            evidence_keys.append(evidence)

    package = {
        "package_id": "A-ARCHETYPE-WAVE-2-CANDIDATE-ADAPTER",
        "owner": "A0",
        "priority": "P1",
        "status": "READY_TO_PUBLISH",
        "branch": "a0/asp-production-conveyor-20260831",
        "sha": BASE_HEAD,
        "paths": [
            "catalog/asp-production-conveyor-v3/a0/archetype-wave-2.v2.json",
            "catalog/asp-production-conveyor-v3/a0/archetype-wave-2-candidate-adapter.v1.json",
            "catalog/asp-production-conveyor-v3/a0/ready-manifests-phase2-repair.v4.json",
            "catalog/asp-production-conveyor-v3/a0/candidate-adapter-queue.v1.json",
            "catalog/asp-production-conveyor-v3/a0/candidate-adapter.schema.json",
            "catalog/asp-production-conveyor-v3/a0/candidate-adapter-receipt.v1.json",
            "tests/asp_production_conveyor_v3_a0_candidate_adapters_test.py",
            "tests/asp_production_conveyor_v3_a0_wave2_source_fidelity_test.py",
        ],
        "source_and_donor_lineage": [
            {"source": "A-ARCHETYPE-WAVE-2", "disposition": "REUSE_CANONICAL_DATA", "scope": "ten current archetypes and twenty desktop/mobile cases after bounded focus-route source-fidelity repair"},
            {"policy": "ASP_NONBLOCKING_WORK_STEALING_V6", "comment": V6_COMMENT, "disposition": "LOWEST_OWNER_REPAIR", "scope": "restore two exact focus-group routes and source pages before compiling the adapter"},
            {"pr": 50, "commit": PR50_COMMIT, "disposition": "REUSE_CANONICAL_DATA", "scope": "route/archetype identities, exact regions, state contracts, component refs and viewport tuples"},
            {"pr": 52, "commit": PR52_COMMIT, "disposition": "REUSE_STRUCTURE_AFTER_RECONSTRUCTION", "scope": "desktop/mobile case ordering only; all Penpot IDs, URLs, screenshots and statuses dropped"},
        ],
        "corpus_projection_state_tuple": {
            "source_head": BASE_HEAD,
            "canonical_corpus_sha256": CANONICAL_CORPUS_SHA,
            "a0_correction_payload_sha": A0_CORRECTION_SHA,
            "wave2_record_sha256": wave2["record_sha256"],
            "wave2_file_sha256": file_sha(BASE / "archetype-wave-2.v2.json"),
            "route_registry_sha256": ROUTE_REGISTRY_SHA,
            "pr52_case_structure_file_sha256": CASE_STRUCTURE_SHA,
            "focus_group_contract_git_blob_sha1": CONTRACT_BLOBS["archetype.focus-group"],
        },
        "archetype_or_route_ids": [load_git_json(PR50_COMMIT, f"catalog/global-archetype-sot-v1/archetype-contracts/{x}")["archetype_id"] for x in CONTRACT_FILES],
        "dependencies": [
            "A-ARCHETYPE-WAVE-2", "U-SHARED-PATTERNS", "U-EVENTCARD-FOUR-CASES",
            "U-RECOVERED-CARD-FAMILIES", "U-CONTROLS-PRIMITIVES",
            "F-SHARED-FOUNDATION-BINDINGS", "F-TYPOGRAPHY-LAYOUT",
            "F-ACTION-NAV-ICONS", "F-MEDALLIONS-BRAND-ASSETS",
        ],
        "target_penpot_page": "a0.candidate.page.archetype-wave-2.v1",
        "expected_roots": root_order,
        "expected_components": sorted(expected_components),
        "expected_instances": {
            "semantic_pages": 1,
            "scenario_roots": 20,
            "archetypes": 10,
            "desktop_cases": 10,
            "mobile_cases": 10,
            "semantic_region_slots": sum(x["expected_instances"]["semantic_region_slots"] for x in steps),
            "specimen_record_bindings": sum(x["expected_instances"]["specimen_record_bindings"] for x in steps),
            "required_component_bindings": sum(x["expected_instances"]["required_component_bindings"] for x in steps),
            "required_state_bindings": sum(x["expected_instances"]["required_state_bindings"] for x in steps),
            "excluded_state_receipts": sum(x["expected_instances"]["excluded_state_receipts"] for x in steps),
        },
        "materialization_entry_point": "D0/MAT or D0/INTEGRATE consumes build_contract.steps in strict order, binds U0/F0 dependencies by semantic ref, and D0/PUBLISH assigns every new Penpot identity.",
        "validation": {
            "schema": "candidate-adapter.schema.json#/$defs/candidate_adapter",
            "positive_and_negative_tests": [
                "tests/asp_production_conveyor_v3_a0_candidate_adapters_test.py",
                "tests/asp_production_conveyor_v3_a0_wave2_source_fidelity_test.py",
            ],
            "visual_acceptance": "PENDING_V0",
            "promotion_authorized": False,
            "specimen_data_is_route_membership": False,
            "focus_group_routes_repaired": True,
        },
        "astro_evidence_cases": evidence_keys,
        "explicit_gaps": [
            "Specimen fixture bindings never assert production route membership.",
            "Interest-club detail historical observation failed; V0 must re-observe the current candidate.",
            "Event-detail tablet remains outside the exact twenty desktop/mobile Wave 2 cases.",
            "/legal/:slug/ remains excluded because no current production source page is present.",
            "Prelaunch-env and unavailable special states remain receipt-only and are not materialized.",
            "Volunteer remains excluded because no factual current canonical route contract exists.",
            "U0/F0 own component and acceptance geometry; V0 visual acceptance remains pending.",
        ],
    }
    package["package_record_sha256"] = record_sha(package, "package_record_sha256")
    adapter: dict[str, Any] = {
        "schema_version": "kenigevents.asp-conveyor.a0.candidate-adapter.v1",
        "adapter_id": "A-ARCHETYPE-WAVE-2-CANDIDATE-ADAPTER.v1",
        "package_manifest": package,
        "materialization_status": "READY_TO_MATERIALIZE_CANDIDATE",
        "acceptance_status": "CANDIDATE_BUILD_NOT_ACCEPTED",
        "visual_acceptance": "PENDING_V0",
        "promotion_authorized": False,
        "penpot_mutations": 0,
        "canonicalization": {
            "algorithm": "RFC8785-compatible project subset: UTF-8 JSON, recursively sorted object keys, arrays preserved, no insignificant whitespace, ensure_ascii=false",
            "record_hash_scope": "entire adapter object excluding receipts",
            "idempotency_hash_scope": "canonical idempotency.material object",
            "file_receipt_scope": "exact committed file bytes",
        },
        "source_inputs": [
            {"path": "catalog/asp-production-conveyor-v3/a0/archetype-wave-2.v2.json", "git_commit": BASE_HEAD, "file_sha256": file_sha(BASE / "archetype-wave-2.v2.json"), "record_sha256": wave2["record_sha256"], "usage": "REPAIRED_CURRENT_WAVE2_SOURCE"},
            {"path": "catalog/asp-production-conveyor-v3/a0/owner-review-index.v1.json", "git_commit": BASE_HEAD, "file_sha256": file_sha(BASE / "owner-review-index.v1.json"), "record_sha256": owner_index["record_sha256"], "usage": "EXACT_TWENTY_CASE_ORDER"},
            {"path": "catalog/global-archetype-sot-v1/route-archetype-registry.v1.json", "git_commit": PR50_COMMIT, "file_sha256": ROUTE_REGISTRY_SHA, "usage": "CANONICAL_ROUTE_ARCHETYPE_DATA"},
            {"path": "catalog/round-trip-reconstruction/v1/owner-review-manifest.v1.json", "git_commit": PR52_COMMIT, "file_sha256": CASE_STRUCTURE_SHA, "usage": "DESKTOP_MOBILE_CASE_ORDER_STRUCTURE_ONLY_AFTER_RECONSTRUCTION"},
        ],
        "contract_receipts": contract_receipts,
        "dependency_refs": [
            {"package_id": x, "owner": owner, "required_at": "MATERIALIZATION", "a0_readiness_assertion": "NONE"}
            for x, owner in [
                ("U-SHARED-PATTERNS", "U0"), ("U-EVENTCARD-FOUR-CASES", "U0"),
                ("U-RECOVERED-CARD-FAMILIES", "U0"), ("U-CONTROLS-PRIMITIVES", "U0"),
                ("F-SHARED-FOUNDATION-BINDINGS", "F0"), ("F-TYPOGRAPHY-LAYOUT", "F0"),
                ("F-ACTION-NAV-ICONS", "F0"), ("F-MEDALLIONS-BRAND-ASSETS", "F0"),
            ]
        ],
        "target": {
            "semantic_page_key": "a0.candidate.page.archetype-wave-2.v1",
            "semantic_page_name": "A0 Candidate · Archetype Wave 2",
            "semantic_root_order": root_order,
            "identity_assignment": "D0_ASSIGNS_ALL_NEW_PENPOT_IDENTITIES",
        },
        "bounded_mutation_scope": {
            "allowed_paths": ["a0.candidate.page.archetype-wave-2.v1", *root_order],
            "max_semantic_pages": 1,
            "max_semantic_roots": 20,
            "existing_non_candidate_pages": "NO_MUTATION",
            "acceptance_geometry": "NOT_OWNED_BY_A0",
            "reversibility": "DELETE_OR_REBUILD_ONLY_ROOTS_WITH_EXACT_IDEMPOTENCY_DIGEST",
        },
        "build_contract": {"ordering": "STRICT_ASCENDING_ORDER", "active_state_selection": "EXACT_SEMANTIC_BASELINE_FROM_PR50_CONTRACT", "steps": steps},
        "readback_contract": {
            "pre": [
                "one exact D0/PUBLISH writer",
                "target semantic page absent or tagged with exact idempotency digest",
                "all source, route, contract and dependency receipts match",
                "focus-group repaired route/source-page tuple matches the PR50 donor exactly",
                "all semantic region/component refs resolve without legacy identity reuse",
            ],
            "post": [
                "one semantic page with exact idempotency digest",
                "twenty roots match target.semantic_root_order byte-for-byte and in order",
                "each root reports archetype, route/source-page tuple, viewport, fixtures, supported/excluded states and semantic bindings",
                "all persisted IDs are newly assigned by D0 and absent from this adapter",
                "validation is empty before V0 handoff",
            ],
        },
        "abort_conditions": [
            "SOURCE_FILE_OR_RECORD_HASH_MISMATCH", "ROUTE_REGISTRY_OR_CONTRACT_RECEIPT_MISMATCH",
            "FOCUS_GROUP_ROUTE_OR_SOURCE_PAGE_OMITTED_CHANGED_OR_REORDERED",
            "CASE_OR_SEMANTIC_ROOT_ORDER_MISMATCH", "FIXTURE_ID_OR_ORDER_MISMATCH",
            "REQUIRED_STATE_OMITTED_OR_CHANGED", "EXCLUDED_STATE_MATERIALIZED_WITHOUT_SOURCE_AUTHORITY",
            "SPECIMEN_FIXTURE_ASSERTED_AS_ROUTE_MEMBERSHIP", "U0_COMPONENT_DEPENDENCY_MISSING_OR_STALE",
            "F0_ASSET_FOUNDATION_OR_GEOMETRY_DEPENDENCY_MISSING_OR_STALE", "MULTIPLE_PENPOT_WRITERS",
            "EXISTING_ROOT_IDEMPOTENCY_DIGEST_MISMATCH", "OLD_PENPOT_UUID_OR_DIRECT_URL_PRESENT",
            "STALE_VISUAL_PASS_OR_ACCEPTANCE_CLAIM", "PROMOTION_REQUESTED_FROM_CANDIDATE_ADAPTER",
        ],
    }
    material = {
        "adapter_id": adapter["adapter_id"],
        "source_tuple": package["corpus_projection_state_tuple"],
        "contract_receipts_sha256": hashlib.sha256(canon(contract_receipts)).hexdigest(),
        "target": adapter["target"],
        "build_steps_sha256": hashlib.sha256(canon(steps)).hexdigest(),
        "bounded_mutation_scope": adapter["bounded_mutation_scope"],
    }
    digest = hashlib.sha256(canon(material)).hexdigest()
    adapter["idempotency"] = {"key": f"a0.archetype-wave-2-candidate.v1:{digest}", "sha256": digest, "material": material}
    adapter["receipts"] = {
        "receipt_path": "catalog/asp-production-conveyor-v3/a0/candidate-adapter-receipt.v1.json",
        "adapter_record_sha256": hashlib.sha256(canon(adapter)).hexdigest(),
    }
    return adapter


def build_owner_adapter(owner_index: dict[str, Any]) -> dict[str, Any]:
    review_keys = [x[1] for x in owner_index["rows"]]
    review_keys_sha = hashlib.sha256(canon(review_keys)).hexdigest()
    roots = ["a0.candidate.root.owner-review-index.desktop.v1", "a0.candidate.root.owner-review-index.mobile.v1"]
    steps = []
    for order, viewport in enumerate(("desktop", "mobile"), 1):
        steps.append({
            "order": order,
            "semantic_root_key": roots[order - 1],
            "scenario_id": f"a0.owner-review-index.{viewport}.v1",
            "evidence_key": f"v0.a0.owner-review-index.{viewport}.v1",
            "viewport": {"id": viewport, "width": 1280 if viewport == "desktop" else 390, "height": 900 if viewport == "desktop" else 844},
            "projection_ref": "catalog/asp-production-conveyor-v3/a0/owner-review-index.v1.json",
            "projection_sha256": owner_index["record_sha256"],
            "fixture_ids": [],
            "fixture_semantics": "NO_EVENT_DATA_REQUIRED",
            "required_states": ["pending"],
            "active_candidate_state": "pending",
            "shell_semantic_slots": ["owner-review.header", "owner-review.package-groups", "owner-review.case-table", "owner-review.status-legend"],
            "component_semantic_refs": [
                "owner-review.index", "owner-review.package-group", "owner-review.case-row", "owner-review.status-chip",
                "shell.desktop-header" if viewport == "desktop" else "shell.mobile-header",
                "shell.footer" if viewport == "desktop" else "shell.mobile-bottom-navigation",
            ],
            "expected_instances": {"semantic_roots": 1, "review_rows": 45, "package_groups": 5, "status_legend": 1},
            "geometry_authority": "OWNER_INDEX_DATA_FROM_A0; U0/F0_OWN_COMPONENT_AND_ACCEPTANCE_GEOMETRY",
        })
    package = {
        "package_id": "A-OWNER-REVIEW-INDEX-CANDIDATE-ADAPTER",
        "owner": "A0", "priority": "P2", "status": "READY_TO_PUBLISH",
        "branch": "a0/asp-production-conveyor-20260831", "sha": BASE_HEAD,
        "paths": [
            "catalog/asp-production-conveyor-v3/a0/owner-review-index.v1.json",
            "catalog/asp-production-conveyor-v3/a0/owner-review-index-candidate-adapter.v1.json",
            "catalog/asp-production-conveyor-v3/a0/candidate-adapter-queue.v1.json",
            "catalog/asp-production-conveyor-v3/a0/candidate-adapter.schema.json",
            "catalog/asp-production-conveyor-v3/a0/candidate-adapter-receipt.v1.json",
            "tests/asp_production_conveyor_v3_a0_candidate_adapters_test.py",
        ],
        "source_and_donor_lineage": [
            {"source": "A-OWNER-REVIEW-INDEX", "disposition": "REUSE_CANONICAL_DATA", "scope": "exact forty-five semantic review keys and package/case order"},
            {"pr": 52, "commit": PR52_COMMIT, "disposition": "REUSE_STRUCTURE_AFTER_RECONSTRUCTION", "scope": "compact review-index concept only; all old Penpot IDs, URLs and statuses dropped"},
            {"policy": "ASP_NONBLOCKING_WORK_STEALING_V6", "comment": V6_COMMENT, "disposition": "INDEPENDENT_BACKLOG_CONTINUATION", "scope": "continued while Wave 2 source-fidelity repair remained bounded"},
        ],
        "corpus_projection_state_tuple": {
            "source_head": BASE_HEAD,
            "owner_review_index_file_sha256": file_sha(BASE / "owner-review-index.v1.json"),
            "owner_review_index_record_sha256": owner_index["record_sha256"],
            "review_keys_sha256": review_keys_sha,
            "entry_count": 45,
            "package_groups": 5,
        },
        "archetype_or_route_ids": ["free-page", "archetype.listing.date", "A-ARCHETYPE-WAVE-1", "A-ARCHETYPE-WAVE-2", "owner-review-index"],
        "dependencies": [
            "A-FREE-FULL-PAGE", "A-DATE-LISTING-SHELL-CANDIDATE-ADAPTER",
            "A-ARCHETYPE-WAVE-1-CANDIDATE-ADAPTER", "A-ARCHETYPE-WAVE-2-CANDIDATE-ADAPTER",
            "U-SHARED-PATTERNS", "F-SHARED-FOUNDATION-BINDINGS",
        ],
        "target_penpot_page": "a0.candidate.page.owner-review-index.v1",
        "expected_roots": roots,
        "expected_components": [
            "owner-review.index", "owner-review.package-group", "owner-review.case-row", "owner-review.status-chip",
            "shell.desktop-header", "shell.footer", "shell.mobile-header", "shell.mobile-bottom-navigation",
        ],
        "expected_instances": {"semantic_pages": 1, "scenario_roots": 2, "review_rows_per_viewport": 45, "total_review_row_instances": 90, "package_groups_per_viewport": 5},
        "materialization_entry_point": "D0/MAT or D0/INTEGRATE consumes the exact owner-review-index source and two ordered build steps; D0/PUBLISH assigns all new Penpot identities.",
        "validation": {"schema": "candidate-adapter.schema.json#/$defs/candidate_adapter", "positive_and_negative_tests": "tests/asp_production_conveyor_v3_a0_candidate_adapters_test.py", "visual_acceptance": "PENDING_V0", "promotion_authorized": False, "legacy_status_inheritance": False},
        "astro_evidence_cases": [x["evidence_key"] for x in steps],
        "explicit_gaps": [
            "This index reports package/case inventory only; it does not promote or visually accept any listed case.",
            "Every row remains pending until D0 persists new identities and V0 supplies direct review.",
        ],
    }
    package["package_record_sha256"] = record_sha(package, "package_record_sha256")
    adapter: dict[str, Any] = {
        "schema_version": "kenigevents.asp-conveyor.a0.candidate-adapter.v1",
        "adapter_id": "A-OWNER-REVIEW-INDEX-CANDIDATE-ADAPTER.v1",
        "package_manifest": package,
        "materialization_status": "READY_TO_MATERIALIZE_CANDIDATE",
        "acceptance_status": "CANDIDATE_BUILD_NOT_ACCEPTED",
        "visual_acceptance": "PENDING_V0",
        "promotion_authorized": False,
        "penpot_mutations": 0,
        "canonicalization": {"algorithm": "RFC8785-compatible project subset: UTF-8 JSON, recursively sorted object keys, arrays preserved, no insignificant whitespace, ensure_ascii=false", "record_hash_scope": "entire adapter object excluding receipts", "idempotency_hash_scope": "canonical idempotency.material object", "file_receipt_scope": "exact committed file bytes"},
        "source_inputs": [{"path": "catalog/asp-production-conveyor-v3/a0/owner-review-index.v1.json", "git_commit": BASE_HEAD, "file_sha256": file_sha(BASE / "owner-review-index.v1.json"), "record_sha256": owner_index["record_sha256"], "usage": "EXACT_FORTY_FIVE_ROW_ORDER"}],
        "dependency_refs": [
            {"package_id": "A-FREE-FULL-PAGE", "owner": "A0", "required_at": "DATA_BINDING", "a0_readiness_assertion": "IMMUTABLE_READY_PACKAGE"},
            {"package_id": "A-DATE-LISTING-SHELL-CANDIDATE-ADAPTER", "owner": "A0", "required_at": "DATA_BINDING", "a0_readiness_assertion": "READY_TO_MATERIALIZE_CANDIDATE"},
            {"package_id": "A-ARCHETYPE-WAVE-1-CANDIDATE-ADAPTER", "owner": "A0", "required_at": "DATA_BINDING", "a0_readiness_assertion": "READY_TO_MATERIALIZE_CANDIDATE"},
            {"package_id": "A-ARCHETYPE-WAVE-2-CANDIDATE-ADAPTER", "owner": "A0", "required_at": "DATA_BINDING", "a0_readiness_assertion": "READY_TO_MATERIALIZE_CANDIDATE"},
            {"package_id": "U-SHARED-PATTERNS", "owner": "U0", "required_at": "MATERIALIZATION", "a0_readiness_assertion": "NONE"},
            {"package_id": "F-SHARED-FOUNDATION-BINDINGS", "owner": "F0", "required_at": "MATERIALIZATION", "a0_readiness_assertion": "NONE"},
        ],
        "index_contract": {
            "columns": owner_index["columns"],
            "review_keys": review_keys,
            "review_keys_sha256": review_keys_sha,
            "package_groups": ["A-FREE-FULL-PAGE", "A-DATE-LISTING-SHELL-REPLAY", "A-ARCHETYPE-WAVE-1", "A-ARCHETYPE-WAVE-2", "OWNER-REVIEW-INDEX"],
            "source_status_policy": {"materialization": "AWAITING_D0_MATERIALIZATION", "v0_acceptance": "PENDING", "target": "D0_ASSIGNS_NEW_ID"},
            "row_count": 45,
        },
        "target": {"semantic_page_key": "a0.candidate.page.owner-review-index.v1", "semantic_page_name": "A0 Candidate · Owner Review Index", "semantic_root_order": roots, "identity_assignment": "D0_ASSIGNS_ALL_NEW_PENPOT_IDENTITIES"},
        "bounded_mutation_scope": {"allowed_paths": ["a0.candidate.page.owner-review-index.v1", *roots], "max_semantic_pages": 1, "max_semantic_roots": 2, "existing_non_candidate_pages": "NO_MUTATION", "acceptance_geometry": "NOT_OWNED_BY_A0", "reversibility": "DELETE_OR_REBUILD_ONLY_ROOTS_WITH_EXACT_IDEMPOTENCY_DIGEST"},
        "build_contract": {"ordering": "STRICT_ASCENDING_ORDER", "steps": steps},
        "readback_contract": {
            "pre": ["one exact D0/PUBLISH writer", "exact forty-five-row source hash matches", "all four referenced package groups resolve by immutable package ID, never Penpot UUID", "target page is absent or tagged with exact idempotency digest"],
            "post": ["one semantic page with exact idempotency digest", "desktop and mobile roots match target.semantic_root_order exactly", "both roots bind the same forty-five review keys byte-for-byte and in order", "all persisted IDs are newly assigned by D0 and absent from this adapter", "every case remains pending before V0 review"],
        },
        "abort_conditions": [
            "OWNER_REVIEW_INDEX_FILE_OR_RECORD_HASH_MISMATCH", "REVIEW_KEY_OMITTED_CHANGED_DUPLICATED_OR_REORDERED",
            "PACKAGE_GROUP_MISSING_OR_RENAMED", "PENDING_STATUS_REPLACED_BY_PASS_OR_ACCEPTED",
            "SEMANTIC_ROOT_ORDER_MISMATCH", "U0_OR_F0_DEPENDENCY_MISSING_OR_STALE", "MULTIPLE_PENPOT_WRITERS",
            "EXISTING_ROOT_IDEMPOTENCY_DIGEST_MISMATCH", "OLD_PENPOT_UUID_OR_DIRECT_URL_PRESENT",
            "STALE_VISUAL_PASS_OR_ACCEPTANCE_CLAIM", "PROMOTION_REQUESTED_FROM_CANDIDATE_ADAPTER",
        ],
    }
    material = {
        "adapter_id": adapter["adapter_id"],
        "source_tuple": package["corpus_projection_state_tuple"],
        "review_keys_sha256": review_keys_sha,
        "target": adapter["target"],
        "build_steps_sha256": hashlib.sha256(canon(steps)).hexdigest(),
        "bounded_mutation_scope": adapter["bounded_mutation_scope"],
    }
    digest = hashlib.sha256(canon(material)).hexdigest()
    adapter["idempotency"] = {"key": f"a0.owner-review-index-candidate.v1:{digest}", "sha256": digest, "material": material}
    adapter["receipts"] = {"receipt_path": "catalog/asp-production-conveyor-v3/a0/candidate-adapter-receipt.v1.json", "adapter_record_sha256": hashlib.sha256(canon(adapter)).hexdigest()}
    return adapter


def build_queue(wave2: dict[str, Any], wave2_adapter: dict[str, Any], owner_adapter: dict[str, Any]) -> dict[str, Any]:
    old = load(BASE / "candidate-adapter-queue.v1.json")
    ready = old["ready"][:2]
    for adapter in (wave2_adapter, owner_adapter):
        ready.append({
            "package_id": adapter["package_manifest"]["package_id"],
            "adapter_path": adapter["package_manifest"]["paths"][1],
            "adapter_record_sha256": adapter["receipts"]["adapter_record_sha256"],
            "package_record_sha256": adapter["package_manifest"]["package_record_sha256"],
            "materialization_status": adapter["materialization_status"],
            "acceptance_status": adapter["acceptance_status"],
            "visual_acceptance": adapter["visual_acceptance"],
            "promotion_authorized": adapter["promotion_authorized"],
        })
    queue = {
        "schema_version": "kenigevents.asp-conveyor.a0.candidate-adapter-queue.v1",
        "ready": ready,
        "repair": [{
            "defect_id": "A0-WAVE2-FOCUS-ROUTE-FIDELITY-001",
            "package_id": "A-ARCHETYPE-WAVE-2",
            "status": "REPAIRED",
            "policy_comment": V6_COMMENT,
            "previous_record_sha256": load(BASE / "archetype-wave-2.v1.json")["record_sha256"],
            "replacement_record_sha256": wave2["record_sha256"],
            "replacement_source_path": "catalog/asp-production-conveyor-v3/a0/archetype-wave-2.v2.json",
            "restored_route_patterns": ["/fokus-gruppa/priglashenie/", "/fokus-gruppa/zavershenie/"],
            "old_penpot_lineage_reused": False,
        }],
        "preparing": [{
            "package_id": "A-SELECTIVE-DONOR-RECOVERY-ARCHETYPE-STRUCTURES-R1",
            "status": "PREPARING",
            "factual_inputs": {
                "archive_library_name": "Новый файл 1 (дизайн система penpot).zip",
                "archive_bytes": 214075969,
                "archive_sha256": "271dad387a11487019cca0d27f01f9895da0f419ec09982ef3eef18a32cf32c3",
                "archive_readback_verified": True,
                "archive_revision": 3141,
                "archive_file_id": "3be9e5e1-190f-8090-8008-713c0fbe6260",
            },
            "bounded_scope": [
                "inventory exact healthy route/archetype structure names and asset hashes",
                "extract semantic anatomy and deterministic composition order only",
                "drop all old page/component/shape/shapeRef UUID lineage and all old visual PASS labels",
            ],
            "remaining_mechanical_work": [
                "map archive objects to current semantic identities without importing the whole file",
                "publish one bounded content-addressed donor package with negative UUID-lineage tests",
            ],
            "product_semantic_decision_required": False,
        }],
        "existing_ready_packages_immutable": old["existing_ready_packages_immutable"],
        "rules": {
            "preparing_must_not_be_empty": True,
            "legacy_penpot_lineage": "FORBIDDEN",
            "visual_status_inheritance": "FORBIDDEN",
            "candidate_is_promotion": False,
            "penpot_mutations": 0,
            "work_stealing_policy": "ASP_NONBLOCKING_WORK_STEALING_V6",
        },
        "receipt_ref": "catalog/asp-production-conveyor-v3/a0/candidate-adapter-receipt.v1.json",
    }
    queue["queue_record_sha256"] = record_sha(queue, "queue_record_sha256")
    return queue


def build_repair_manifest(wave2: dict[str, Any], wave2_adapter: dict[str, Any], owner_adapter: dict[str, Any]) -> dict[str, Any]:
    old = load(BASE / "archetype-wave-2.v1.json")
    manifest = {
        "schema_version": "kenigevents.asp-conveyor.a0.ready-manifests-phase2-repair.v4",
        "policy": {"name": "ASP_NONBLOCKING_WORK_STEALING_V6", "comment": V6_COMMENT, "contract_path": "docs/product-governance/asp-production-conveyor-v3/WORK_STEALING_V6.md", "contract_commit": "e890d819c50b2220c5e20c8bcbace638005ffa1f"},
        "defect": {
            "defect_id": "A0-WAVE2-FOCUS-ROUTE-FIDELITY-001", "lowest_owner": "A0",
            "classification": "SOURCE_FIDELITY_ROUTE_AND_SOURCE_PAGE_OMISSION", "affected_package": "A-ARCHETYPE-WAVE-2",
            "old_source_path": "catalog/asp-production-conveyor-v3/a0/archetype-wave-2.v1.json",
            "old_source_record_sha256": old["record_sha256"],
            "donor_contract": {"path": "catalog/global-archetype-sot-v1/archetype-contracts/focus-group.semantic-contract.v1.json", "commit": PR50_COMMIT, "git_blob_sha1": CONTRACT_BLOBS["archetype.focus-group"]},
            "missing_route_patterns": ["/fokus-gruppa/priglashenie/", "/fokus-gruppa/zavershenie/"],
            "missing_source_pages": ["site/src/pages/fokus-gruppa/priglashenie/index.astro", "site/src/pages/fokus-gruppa/zavershenie/index.astro"],
        },
        "repair": {
            "status": "REPAIRED_WITH_VERSIONED_REPLACEMENT",
            "replacement_source_path": "catalog/asp-production-conveyor-v3/a0/archetype-wave-2.v2.json",
            "replacement_source_file_sha256": file_sha(BASE / "archetype-wave-2.v2.json"),
            "replacement_source_record_sha256": wave2["record_sha256"],
            "case_count_unchanged": 20, "archetype_count_unchanged": 10,
            "product_semantics_changed": False, "penpot_lineage_reused": False, "old_visual_status_inherited": False,
        },
        "replacement_package": wave2_adapter["package_manifest"],
        "independent_backlog_delivery": {
            "package_id": owner_adapter["package_manifest"]["package_id"],
            "adapter_record_sha256": owner_adapter["receipts"]["adapter_record_sha256"],
            "package_record_sha256": owner_adapter["package_manifest"]["package_record_sha256"],
            "status": "READY_TO_MATERIALIZE_CANDIDATE", "promotion_authorized": False,
        },
    }
    manifest["record_sha256"] = record_sha(manifest, "record_sha256")
    return manifest


CANDIDATE_TEST = r'''#!/usr/bin/env python3
from pathlib import Path
import copy, hashlib, json, re
from jsonschema import Draft202012Validator, ValidationError
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'catalog/asp-production-conveyor-v3/a0'
def load(name): return json.loads((BASE/name).read_text(encoding='utf-8'))
def canon(o): return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(o): return hashlib.sha256(canon(o)).hexdigest()
def file_sha(path): return hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
schema_doc=load('candidate-adapter.schema.json')
def validator(name): return Draft202012Validator({'$schema':'https://json-schema.org/draft/2020-12/schema','$defs':schema_doc['$defs'],'$ref':f'#/$defs/{name}'})
def validate(obj,name): validator(name).validate(obj)
def invalid(obj,name):
    try: validate(obj,name)
    except ValidationError: return
    raise AssertionError('negative case unexpectedly validated')
uuid=re.compile(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')
forbidden_keys={'page_id','board_id','component_id','shape_id','direct_url','penpot_uuid','screenshot'}
def forbid(v):
    if isinstance(v,dict):
        for k,x in v.items():
            assert k not in forbidden_keys,k
            forbid(x)
    elif isinstance(v,list):
        for x in v: forbid(x)
    elif isinstance(v,str):
        assert not uuid.fullmatch(v),v
        assert 'design.penpot.app' not in v,v
        assert v not in {'PASS','REVIEWABLE','ACCEPTED','READY_TO_PROMOTE'},v
n=0
def check(value,label):
    global n
    assert value,label
    n+=1
def verify_adapter(a):
    validate(a,'candidate_adapter'); check(True,'schema')
    check(sha({k:v for k,v in a.items() if k!='receipts'})==a['receipts']['adapter_record_sha256'],'adapter hash')
    p=a['package_manifest']; check(sha({k:v for k,v in p.items() if k!='package_record_sha256'})==p['package_record_sha256'],'package hash')
    check(sha(a['idempotency']['material'])==a['idempotency']['sha256'],'idempotency hash')
    check(a['idempotency']['key'].endswith(a['idempotency']['sha256']),'idempotency key')
    steps=a['build_contract']['steps']
    check([x['order'] for x in steps]==list(range(1,len(steps)+1)),'step order')
    check([x['semantic_root_key'] for x in steps]==a['target']['semantic_root_order'],'root order')
    m=a['idempotency']['material']
    if 'build_steps' in m: check(steps==m['build_steps'],'full idempotency steps')
    else: check(sha(steps)==m['build_steps_sha256'],'compact idempotency steps')
    check(a['target']==m['target'],'target receipt')
    check(a['bounded_mutation_scope']==m['bounded_mutation_scope'],'scope receipt')
    if 'contract_receipts' in a: check(sha(a['contract_receipts'])==m['contract_receipts_sha256'],'contract receipts')
    check(a['promotion_authorized'] is False and a['penpot_mutations']==0,'candidate boundary')
    forbid(a); check(True,'forbidden lineage')
date=load('date-listing-shell-candidate-adapter.v1.json')
wave1=load('archetype-wave-1-candidate-adapter.v1.json')
wave2=load('archetype-wave-2-candidate-adapter.v1.json')
owner=load('owner-review-index-candidate-adapter.v1.json')
source2=load('archetype-wave-2.v2.json')
index=load('owner-review-index.v1.json')
queue=load('candidate-adapter-queue.v1.json')
receipt=load('candidate-adapter-receipt.v1.json')
for a in (date,wave1,wave2,owner): verify_adapter(a)
# Preserve exact Date and Wave 1 contracts.
ds=date['build_contract']['steps']
check(len(ds)==7,'date count')
check([x['scenario_id'] for x in ds]==['a0.date.typical.desktop.v1','a0.date.typical.mobile.v1','a0.date.sparse.desktop.v1','a0.date.state-matrix.mobile.v1','a0.date.stress.desktop.v1','a0.date.full.desktop.v1','a0.date.full.mobile.v1'],'date scenarios')
check([x['fixture_ids'] for x in ds]==[['event.real.8006'],['event.real.8006'],['event.real.8200'],[],['event.real.4240','event.real.8006','event.real.8200'],['event.real.8006'],['event.real.8006']],'date fixtures')
check(ds[3]['required_states']==['loading','empty','error'],'date states')
ws=wave1['build_contract']['steps']
check(len(ws)==12,'wave1 count')
check([x['archetype_id'] for x in ws[::2]]==['archetype.home','archetype.listing.weekend','archetype.listing.popular','archetype.listing.unusual','archetype.collections','archetype.exhibitions'],'wave1 order')
check(all(x['fixture_semantics']=='REFERENCE_ONLY_NOT_ROUTE_MEMBERSHIP' for x in ws),'wave1 fixture policy')
check([x['viewport']['id'] for x in ws]==['desktop','mobile']*6,'wave1 viewports')
check(all(x['active_candidate_state'] in x['required_states'] for x in ws),'wave1 active states')
check(len({x['evidence_key'] for x in ws})==12,'wave1 evidence')
# Wave 2 exact twenty-case executable adapter and source repair.
w2=wave2['build_contract']['steps']
ids=['archetype.search','archetype.favorites','archetype.personal-feed','archetype.festivals','archetype.interest-clubs','archetype.artifacts','archetype.event-detail','archetype.focus-group','archetype.information-pages','archetype.special-state']
check(len(w2)==20,'wave2 count')
check([x['archetype_id'] for x in w2[::2]]==ids,'wave2 archetype order')
check([x['viewport']['id'] for x in w2]==['desktop','mobile']*10,'wave2 viewport order')
check(len({x['evidence_key'] for x in w2})==20,'wave2 evidence')
check(all(x['fixture_semantics'] in {'REFERENCE_ONLY_NOT_ROUTE_MEMBERSHIP','NO_EVENT_DATA_REQUIRED'} for x in w2),'wave2 fixture policy')
check(all(x['active_candidate_state'] in x['required_states'] for x in w2),'wave2 active states')
check(all(x['projection_sha256']==source2['record_sha256'] for x in w2),'wave2 projection receipt')
check(all('archetype-wave-2.v2.json#archetypes/' in x['projection_ref'] for x in w2),'wave2 v2 refs')
focus=[x for x in w2 if x['archetype_id']=='archetype.focus-group']
focus_routes=['/fokus-gruppa/','/fokus-gruppa/priglashenie/','/fokus-gruppa/diagnostika/','/fokus-gruppa/diagnostika-ustoychivost/','/fokus-gruppa/kollektsiya/','/fokus-gruppa/zavershenie/']
focus_pages=['site/src/pages/fokus-gruppa/index.astro','site/src/pages/fokus-gruppa/priglashenie/index.astro','site/src/pages/fokus-gruppa/diagnostika/index.astro','site/src/pages/fokus-gruppa/diagnostika-ustoychivost/index.astro','site/src/pages/fokus-gruppa/kollektsiya/index.astro','site/src/pages/fokus-gruppa/zavershenie/index.astro']
check(all(x['route_patterns']==focus_routes for x in focus),'focus routes')
check(all(x['source_pages']==focus_pages for x in focus),'focus pages')
info=next(x for x in w2 if x['archetype_id']=='archetype.information-pages')
special=next(x for x in w2 if x['archetype_id']=='archetype.special-state')
check(info['excluded_unmaterialized_states']==['legal-document'],'info exclusion')
check(special['excluded_unmaterialized_states']==['prelaunch-env','unavailable'],'special exclusions')
check(source2['volunteer']['status']=='EXCLUDED_NO_FACTUAL_CURRENT_ROUTE_CONTRACT','volunteer boundary')
# Independent compact owner-review index adapter.
os=owner['build_contract']['steps']
check(len(os)==2 and [x['viewport']['id'] for x in os]==['desktop','mobile'],'index cases')
check(owner['index_contract']['review_keys']==[x[1] for x in index['rows']],'index key order')
check(owner['index_contract']['review_keys_sha256']==sha([x[1] for x in index['rows']]),'index keys hash')
check(owner['index_contract']['row_count']==45,'index row count')
check(all(x['active_candidate_state']=='pending' for x in os),'index pending')
# Queue and receipt remain content addressed, with real independent PREPARING work.
validate(queue,'queue'); check(True,'queue schema')
check(sha({k:v for k,v in queue.items() if k!='queue_record_sha256'})==queue['queue_record_sha256'],'queue hash')
check([x['package_id'] for x in queue['ready']]==['A-DATE-LISTING-SHELL-CANDIDATE-ADAPTER','A-ARCHETYPE-WAVE-1-CANDIDATE-ADAPTER','A-ARCHETYPE-WAVE-2-CANDIDATE-ADAPTER','A-OWNER-REVIEW-INDEX-CANDIDATE-ADAPTER'],'queue ready')
check([x['package_id'] for x in queue['preparing']]==['A-SELECTIVE-DONOR-RECOVERY-ARCHETYPE-STRUCTURES-R1'],'queue preparing')
check(queue['repair'][0]['status']=='REPAIRED','repair state')
check(len(queue['existing_ready_packages_immutable'])==8,'immutable baseline')
validate(receipt,'receipt'); check(True,'receipt schema')
check(sha({k:v for k,v in receipt.items() if k!='receipt_record_sha256'})==receipt['receipt_record_sha256'],'receipt hash')
for f in receipt['files']: check(file_sha(f['path'])==f['file_sha256'],f['path'])
check(receipt['record_hashes']['wave2_adapter_record_sha256']==wave2['receipts']['adapter_record_sha256'],'wave2 receipt')
check(receipt['record_hashes']['owner_index_adapter_record_sha256']==owner['receipts']['adapter_record_sha256'],'owner receipt')
check(receipt['record_hashes']['queue_record_sha256']==queue['queue_record_sha256'],'queue receipt')
# Required negative cases.
for mutate,label in [
    (lambda b:b.update(promotion_authorized=True),'promotion'),
    (lambda b:b.update(visual_acceptance='PASS'),'visual pass'),
    (lambda b:b['build_contract']['steps'][14].update(route_patterns=['/fokus-gruppa/']),'focus route omission'),
    (lambda b:b['build_contract']['steps'][14].update(source_pages=['site/src/pages/fokus-gruppa/index.astro']),'focus page omission'),
    (lambda b:b['build_contract']['steps'][0].update(required_states=[]),'state omission'),
    (lambda b:b['target'].update(semantic_root_order=list(reversed(b['target']['semantic_root_order']))),'root order'),
]:
    bad=copy.deepcopy(wave2); mutate(bad)
    try: verify_adapter(bad)
    except (AssertionError,ValidationError): check(True,label)
    else: raise AssertionError(label+' accepted')
bad=copy.deepcopy(owner); bad['index_contract']['review_keys'].pop()
try: verify_adapter(bad)
except (AssertionError,ValidationError): check(True,'owner key omission')
else: raise AssertionError('owner key omission accepted')
bad=copy.deepcopy(wave2); bad['target']['legacy']='d87e18f1-dcb4-80a6-8008-8806c5b98101'
try: forbid(bad)
except AssertionError: check(True,'UUID')
else: raise AssertionError('UUID accepted')
bad=copy.deepcopy(queue); bad['preparing']=[]; invalid(bad,'queue'); check(True,'empty preparing')
bad=copy.deepcopy(receipt); bad['files'][0]['file_sha256']='0'*64
try: check(sha({k:v for k,v in bad.items() if k!='receipt_record_sha256'})==bad['receipt_record_sha256'],'bad receipt')
except AssertionError: n+=1
else: raise AssertionError('receipt mismatch accepted')
print(json.dumps({'status':'PASS','checks_passed':n,'checks_failed':0},separators=(',',':')))
'''

FIDELITY_TEST = r'''#!/usr/bin/env python3
from pathlib import Path
import copy, hashlib, json, re, subprocess
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'catalog/asp-production-conveyor-v3/a0'
def load(path): return json.loads(path.read_text(encoding='utf-8'))
def canon(o): return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(o): return hashlib.sha256(canon(o)).hexdigest()
old=load(BASE/'archetype-wave-2.v1.json')
new=load(BASE/'archetype-wave-2.v2.json')
focus=json.loads(subprocess.check_output(['git','show','9b8043f3bdb86fab4eee00bf94b0f10d4f029c50:catalog/global-archetype-sot-v1/archetype-contracts/focus-group.semantic-contract.v1.json'],cwd=ROOT).decode('utf-8'))
manifest=load(BASE/'ready-manifests-phase2-repair.v4.json')
n=0
def check(v,label):
    global n
    assert v,label
    n+=1
old_focus=next(x for x in old['archetypes'] if x['archetype_id']=='archetype.focus-group')
new_focus=next(x for x in new['archetypes'] if x['archetype_id']=='archetype.focus-group')
check('/fokus-gruppa/priglashenie/' not in old_focus['route_patterns'],'old invitation omitted')
check('/fokus-gruppa/zavershenie/' not in old_focus['route_patterns'],'old completion omitted')
check(new_focus['route_patterns']==focus['route_contract']['route_patterns'],'exact route repair')
check(new_focus['source_pages']==focus['route_contract']['source_pages'],'exact source-page repair')
check(new['count']==old['count']==10 and new['case_count']==old['case_count']==20,'counts stable')
check(new['supersedes']['record_sha256']==old['record_sha256'],'supersedes receipt')
check(new['repair_lineage']['policy_comment']==5481580183,'V6 policy')
check(new['repair_lineage']['restored_route_patterns']==['/fokus-gruppa/priglashenie/','/fokus-gruppa/zavershenie/'],'restored routes')
check(new['repair_lineage']['restored_source_pages']==['site/src/pages/fokus-gruppa/priglashenie/index.astro','site/src/pages/fokus-gruppa/zavershenie/index.astro'],'restored pages')
check(sha({k:v for k,v in new.items() if k!='record_sha256'})==new['record_sha256'],'source record hash')
check(sha({k:v for k,v in manifest.items() if k!='record_sha256'})==manifest['record_sha256'],'manifest record hash')
check(manifest['repair']['replacement_source_record_sha256']==new['record_sha256'],'manifest source receipt')
check(manifest['repair']['case_count_unchanged']==20 and manifest['repair']['product_semantics_changed'] is False,'bounded repair')
check(manifest['repair']['penpot_lineage_reused'] is False and manifest['repair']['old_visual_status_inherited'] is False,'lineage boundary')
check(new['volunteer']['status']=='EXCLUDED_NO_FACTUAL_CURRENT_ROUTE_CONTRACT','volunteer unchanged')
text=json.dumps(new,ensure_ascii=False)
check('design.penpot.app' not in text,'no direct URL')
check(not re.search(r'"(?:page_id|board_id|component_id|shape_id|penpot_uuid)"',text),'no UUID keys')
for key in ('route_patterns','source_pages'):
    bad=copy.deepcopy(new)
    target=next(x for x in bad['archetypes'] if x['archetype_id']=='archetype.focus-group')
    target[key]=target[key][:-1]
    check(target[key] != focus['route_contract'][key],'negative '+key)
print(json.dumps({'status':'PASS','checks_passed':n,'checks_failed':0},separators=(',',':')))
'''


def build_receipt(wave2: dict[str, Any], wave2_adapter: dict[str, Any], owner_adapter: dict[str, Any], queue: dict[str, Any], validation: dict[str, Any]) -> dict[str, Any]:
    paths = [
        "catalog/asp-production-conveyor-v3/a0/date-listing-shell-candidate-adapter.v1.json",
        "catalog/asp-production-conveyor-v3/a0/archetype-wave-1-candidate-adapter.v1.json",
        "catalog/asp-production-conveyor-v3/a0/archetype-wave-2-candidate-adapter.v1.json",
        "catalog/asp-production-conveyor-v3/a0/owner-review-index-candidate-adapter.v1.json",
        "catalog/asp-production-conveyor-v3/a0/candidate-adapter-queue.v1.json",
        "catalog/asp-production-conveyor-v3/a0/candidate-adapter.schema.json",
        "catalog/asp-production-conveyor-v3/a0/archetype-wave-1.v1.json",
        "catalog/asp-production-conveyor-v3/a0/archetype-wave-2.v1.json",
        "catalog/asp-production-conveyor-v3/a0/archetype-wave-2.v2.json",
        "catalog/asp-production-conveyor-v3/a0/owner-review-index.v1.json",
        "catalog/asp-production-conveyor-v3/a0/ready-manifests-phase2-repair.v4.json",
        "tests/asp_production_conveyor_v3_a0_candidate_adapters_test.py",
        "tests/asp_production_conveyor_v3_a0_wave2_source_fidelity_test.py",
    ]
    date = load(BASE / "date-listing-shell-candidate-adapter.v1.json")
    wave1 = load(BASE / "archetype-wave-1-candidate-adapter.v1.json")
    receipt = {
        "schema_version": "kenigevents.asp-conveyor.a0.candidate-adapter-receipt.v1",
        "canonicalization": {
            "algorithm": "UTF-8 JSON, recursively sorted object keys, arrays preserved, separators comma/colon, ensure_ascii=false",
            "file_hash_scope": "exact file bytes",
            "record_hash_scope": "canonical object excluding its declared receipt/hash field",
        },
        "files": [{"path": x, "file_sha256": file_sha(ROOT / x)} for x in paths],
        "record_hashes": {
            "date_adapter_record_sha256": date["receipts"]["adapter_record_sha256"],
            "date_package_record_sha256": date["package_manifest"]["package_record_sha256"],
            "date_idempotency_sha256": date["idempotency"]["sha256"],
            "wave1_adapter_record_sha256": wave1["receipts"]["adapter_record_sha256"],
            "wave1_package_record_sha256": wave1["package_manifest"]["package_record_sha256"],
            "wave1_idempotency_sha256": wave1["idempotency"]["sha256"],
            "wave2_adapter_record_sha256": wave2_adapter["receipts"]["adapter_record_sha256"],
            "wave2_package_record_sha256": wave2_adapter["package_manifest"]["package_record_sha256"],
            "wave2_idempotency_sha256": wave2_adapter["idempotency"]["sha256"],
            "owner_index_adapter_record_sha256": owner_adapter["receipts"]["adapter_record_sha256"],
            "owner_index_package_record_sha256": owner_adapter["package_manifest"]["package_record_sha256"],
            "owner_index_idempotency_sha256": owner_adapter["idempotency"]["sha256"],
            "queue_record_sha256": queue["queue_record_sha256"],
        },
        "source_tuple": {
            "canonical_corpus_sha256": CANONICAL_CORPUS_SHA,
            "date_replay_record_sha256": "75ef44c4b460c8c7f5632feaad667e4f5a80f01063874286da0001ceeda96023",
            "wave1_record_sha256": load(BASE / "archetype-wave-1.v1.json")["record_sha256"],
            "wave2_v1_record_sha256": load(BASE / "archetype-wave-2.v1.json")["record_sha256"],
            "wave2_v2_record_sha256": wave2["record_sha256"],
            "owner_review_index_record_sha256": load(BASE / "owner-review-index.v1.json")["record_sha256"],
            "route_registry_sha256": ROUTE_REGISTRY_SHA,
            "pr52_case_structure_file_sha256": CASE_STRUCTURE_SHA,
        },
        "repair_receipt": {
            "defect_id": "A0-WAVE2-FOCUS-ROUTE-FIDELITY-001",
            "policy_comment": V6_COMMENT,
            "old_source_preserved": True,
            "replacement_source": "catalog/asp-production-conveyor-v3/a0/archetype-wave-2.v2.json",
            "restored_route_patterns": ["/fokus-gruppa/priglashenie/", "/fokus-gruppa/zavershenie/"],
            "old_penpot_lineage_reused": False,
        },
        "penpot_mutations": 0,
        "validation": validation,
    }
    receipt["receipt_record_sha256"] = record_sha(receipt, "receipt_record_sha256")
    return receipt


def main() -> None:
    contracts: dict[str, dict[str, Any]] = {}
    for filename in CONTRACT_FILES:
        path = f"catalog/global-archetype-sot-v1/archetype-contracts/{filename}"
        contract = load_git_json(PR50_COMMIT, path)
        archetype_id = contract["archetype_id"]
        actual_blob = git_blob(PR50_COMMIT, path)
        if actual_blob != CONTRACT_BLOBS[archetype_id]:
            raise AssertionError(f"contract blob mismatch for {archetype_id}: {actual_blob}")
        contracts[archetype_id] = contract
    owner_index = load(BASE / "owner-review-index.v1.json")
    wave2 = build_wave2_source(contracts)
    write_json(BASE / "archetype-wave-2.v2.json", wave2, pretty=False)
    wave2_adapter = build_wave2_adapter(wave2, owner_index, contracts)
    write_json(BASE / "archetype-wave-2-candidate-adapter.v1.json", wave2_adapter)
    owner_adapter = build_owner_adapter(owner_index)
    write_json(BASE / "owner-review-index-candidate-adapter.v1.json", owner_adapter)
    queue = build_queue(wave2, wave2_adapter, owner_adapter)
    write_json(BASE / "candidate-adapter-queue.v1.json", queue)
    repair_manifest = build_repair_manifest(wave2, wave2_adapter, owner_adapter)
    write_json(BASE / "ready-manifests-phase2-repair.v4.json", repair_manifest)
    (TESTS / "asp_production_conveyor_v3_a0_candidate_adapters_test.py").write_text(CANDIDATE_TEST, encoding="utf-8")
    (TESTS / "asp_production_conveyor_v3_a0_wave2_source_fidelity_test.py").write_text(FIDELITY_TEST, encoding="utf-8")

    provisional = build_receipt(wave2, wave2_adapter, owner_adapter, queue, {"state": "PROVISIONAL_TEST_EXECUTION"})
    write_json(BASE / "candidate-adapter-receipt.v1.json", provisional)

    commands = [
        [sys.executable, "tests/asp_production_conveyor_v3_a0_bundle_test.py"],
        [sys.executable, "tests/asp_production_conveyor_v3_a0_candidate_adapters_test.py"],
        [sys.executable, "tests/asp_production_conveyor_v3_a0_phase2_test.py"],
        [sys.executable, "tests/asp_production_conveyor_v3_a0_wave2_source_fidelity_test.py"],
    ]
    first = [run_json(x) for x in commands]
    subprocess.run([sys.executable, "-m", "py_compile", *[str(x) for x in sorted(TESTS.glob("asp_production_conveyor_v3_a0_*_test.py"))]], cwd=ROOT, check=True)
    subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
    validation = {
        "validated_payload_base": BASE_HEAD,
        "commands": [
            {"command": " ".join(cmd), "checks_passed": out["checks_passed"], "checks_failed": out["checks_failed"]}
            for cmd, out in zip(commands, first)
        ] + [
            {"command": "python3 -m py_compile tests/asp_production_conveyor_v3_a0_*_test.py", "process_exit_code": 0},
            {"command": "git diff --check", "process_exit_code": 0},
        ],
        "schema_and_semantic_checks_passed": sum(x["checks_passed"] for x in first),
        "schema_and_semantic_checks_failed": sum(x["checks_failed"] for x in first),
        "work_stealing_policy": "ASP_NONBLOCKING_WORK_STEALING_V6",
        "focus_route_repair": "PASS",
        "independent_owner_index_adapter": "PASS",
    }
    final_receipt = build_receipt(wave2, wave2_adapter, owner_adapter, queue, validation)
    write_json(BASE / "candidate-adapter-receipt.v1.json", final_receipt)

    second = [run_json(x) for x in commands]
    if first != second:
        raise AssertionError(f"non-deterministic validation outputs: {first!r} != {second!r}")
    subprocess.run([sys.executable, "-m", "py_compile", *[str(x) for x in sorted(TESTS.glob("asp_production_conveyor_v3_a0_*_test.py"))]], cwd=ROOT, check=True)
    subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
    print(json.dumps({
        "status": "PASS",
        "wave2_record_sha256": wave2["record_sha256"],
        "wave2_adapter_record_sha256": wave2_adapter["receipts"]["adapter_record_sha256"],
        "owner_index_adapter_record_sha256": owner_adapter["receipts"]["adapter_record_sha256"],
        "queue_record_sha256": queue["queue_record_sha256"],
        "receipt_record_sha256": final_receipt["receipt_record_sha256"],
        "checks_passed": validation["schema_and_semantic_checks_passed"],
        "checks_failed": validation["schema_and_semantic_checks_failed"],
    }, separators=(",", ":")))


if __name__ == "__main__":
    main()
